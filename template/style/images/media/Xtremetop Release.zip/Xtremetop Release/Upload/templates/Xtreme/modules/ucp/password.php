<?php
/***************************************************************************
 *                                password.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Subpage
{
	static $data = array
	(
		'color'		=> 'red',
		'message' 	=> '',
	);

	static function Build()
	{
		if(User::$isLoggedin != TRUE)
		{
			redirect('login');
		}

		if(isset($_POST['edit']))
		{
			self::change_password();
		}

		Load::view('ucp/password', self::$data);
	}
	
	static function change_password()
	{
		foreach($_POST as $k => $v)
		{
			if(empty($v))
			{
				return self::$data['message'] = 'The ' . ucfirst($k) . ' password cannot be empty';
			}
		}

		if($_POST['previous'] == $_SESSION['password'])
		{
			if($_POST['new'] == $_POST['confirm'])
			{
				$username  = User::$username; 
				$new_pass  = DB::safe($_POST['new']);
				$encrypted = md5($username . $new_pass);
				$_SESSION['password'] = $new_pass;

				DB::query("UPDATE top_topsites SET password = '$encrypted' WHERE username = '$username' LIMIT 1");
				self::$data['message'] = 'Your password has been updated';
				self::$data['color'] = 'green';
			}

			else self::$data['message'] = 'Your passwords do not match';
		}

		else self::$data['message'] = 'Incorrect password';
	}
}