<?php
/***************************************************************************
 *                                last.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Page
{
	static $data = array('current' => 'last');

	static function Build($start = 1)
	{
		$start = (is_numeric($start) && $start > 0) ? $start : 1;
		self::$data['start'] = $start;

		$category = (isset($_GET['category']) && is_numeric($_GET['category'])) ? $_GET['category'] : FALSE;		
		self::$data['category'] = $category;

		Load::view('index', self::$data);
	}
	
	static function sites()
	{
		$start		= self::$data['start'] - 1;
		$max		= Config::item('sites_per_page') * Config::item('max_pages');
		$category	= self::$data['category'];

		$category	= self::$data['category'];		
		$WHERE = 'WHERE title != \'\' AND description != \'\'';
		
		if($category != FALSE)
		{
			$WHERE .= ' AND category = \''.$category.'\'';
		}

		DB::query("SELECT * FROM top_topsites $WHERE ORDER BY `id` DESC LIMIT $start, $max");
		self::$data['count'] = DB::num_rows();

		if(DB::num_rows() > 0)
		{
			$return = DB::fetch_array();
		
			if(DB::num_rows() > 50)
			{
				$i = 0;
				$new = array();

				while(50 > $i)
				{
					$new[] = $return[$i];
					$i++;
				}
				
				$return = $new;
			}
	
			return $return;
		}

		return array();
	}
}