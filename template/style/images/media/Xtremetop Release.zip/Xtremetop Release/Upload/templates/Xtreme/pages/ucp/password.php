<div id="middlebtop">Edit account</div>
<div id="middlebtopa">
<small>
<span style="font-size: 12px; font-family:Verdana;">



<ul id="thicktabs">
	<li><a href="?ucp" id="leftmostitem">Main edit</a></li>
	<li><a href="?edit=details">Website details</a></li>
	<li><a href="?edit=screenshots">Upload screenshots</a></li>
	<li><a href="?edit=membership">Gold membership</a></li>	
	<li><a href="?edit=htmlcode">Get HTML code</a></li>
	<span style="float:right; font-size: 13px; color: red;"><li><a href="?logout">Logout!</a></li></span>
</ul>
<br style="clear: left" />



<br />

		<div style="background-color: #fbfaef; padding-top: 1px; padding-bottom: 5px; padding-right: 8px; border-right-width: 1pt; border-bottom-width: 1pt; border-top-width: 1pt; border-left-width: 1pt; border-right-style: solid; border-bottom-style: solid; border-top-style: solid; border-left-style: solid; border-right-color: #BFBBBA; border-bottom-color: #BFBBBA; border-left-color: #BFBBBA; border-top-color: #BFBBBA;">
		<ul>
		<li>Your account/website information may take up to five minutes to update on the toplist.<br /></li>
		<li>You username cannot be edited. If you wish to change it, please contact the admin.</li>
		</ul>
		</div>

			<form action="?edit=password" method="post">
				<br />
				<i><b>
				<font size="3" color="#3399FF">Change Password:</font></b></i>
				<br />
				<b style="color: <?php echo $color; ?>;"><?php echo $message; ?></b>
				<table border="0" width="734" cellspacing="4" cellpadding="4">
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Previous Password:</font></b></td>
						<td valign="top">
						<input type="password" name="previous" size="37" value=""></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">New Password:</font></b></td>
						<td valign="top">
						<input type="password" name="new" size="37" value=""></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Confirm Password:</font></b></td>
						<td valign="top">
						<input type="password" name="confirm" size="37" value=""></td>
					</tr>
					<tr>
						<td width="147">&nbsp;</td>
						<td><input type="submit" value="Change Password!" name="edit"></td>
					</tr>
					<tr>
						<td width="147">&nbsp;</td>
						<td>&nbsp;</td>
					</tr>
				</table>
		

			</form>


	</span>
	</small>
	</div>
