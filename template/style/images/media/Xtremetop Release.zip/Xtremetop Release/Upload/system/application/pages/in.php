<?php
/***************************************************************************
 *                                in.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Page
{
	static function Build()
	{
		if(empty($_GET['in']) || !is_numeric($_GET['in']))
		{
			redirect();
		}

		$id = $_GET['in'];
		DB::query("SELECT id, category, title as sitename FROM top_topsites WHERE id = '$id'");

		if(DB::num_rows() > 0)
		{
			$data = DB::fetch_row();
			$data['message'] = '<small>Please enter the following text in the box.</small>';
			$ip = (getenv('HTTP_X_FORWARDED_FOR')) ? getenv('HTTP_X_FORWARDED_FOR') : getenv('REMOTE_ADDR');

			Load::library('recaptcha');
			
			global $publickey, $privatekey;
			$publickey = "6Lc6grsSAAAAALJfZOsAVPG5FYdB1hXGBTUNI4k9";
			$privatekey = "6Lc6grsSAAAAAFVepWvKXnkJgXDEiT6DPBzQBHlu";

			$resp = null;
			$error = null;

			if(isset($_POST['vote']))
			{
				$resp = recaptcha_check_answer($privatekey, $_SERVER['REMOTE_ADDR'], $_POST['recaptcha_challenge_field'], $_POST["recaptcha_response_field"]);

				if($resp->is_valid == TRUE)
				{
					if(self::already_voted($id, $ip) == FALSE)
					{
						$time = time();
						
						//Add point to site
						$q = "UPDATE top_topsites SET `in` = `in` + 1, `intotal` = `intotal` + 1 WHERE id = '$id' LIMIT 1";
						DB::query($q);
						
						//Log vote
						$q = "INSERT INTO top_actions SET siteid = '$id', ip = '$ip', action = '2', `timestamp` = '$time'";
						DB::query($q);

						redirect('index=1&category='.$data['category']);
					}

					else redirect('index=1&category='.$data['category']);
				}
				
				else $error = $resp->error;
			}
		}

		else redirect();
		
		$data['publickey']	= $publickey;
		$data['error']		= $error;
		$data['current']	= 'index';

		Load::view('in', $data);
	}

	static function already_voted($id, $ip)
	{
		DB::select('top_actions', "ip = '$ip' AND siteid = '$id' AND action = '2' ORDER BY `timestamp` DESC", '1');

		if(DB::num_rows() > 0)
		{
			$info = DB::fetch_row();

			if($info['timestamp'] >= time() - 60*60*12)
			{
				return TRUE;
			}
		}

		return FALSE;
	}
	
	static function msg($message = '', $color = 'red')
	{
		return '<b style=\'color:'.$color.';\'>'.$message.'</b>';
	}
}