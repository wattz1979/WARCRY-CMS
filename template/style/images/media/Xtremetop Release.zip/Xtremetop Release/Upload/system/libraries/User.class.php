<?php
/***************************************************************************
 *                                User.php
 *                            -------------------
 *   Project              : Flamework
 *   Begin                : June 2, 2010
 *   Copyright            : (C) 2009 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

if(!defined('IN_TOPSITE')) die();

class User
{
	static $isLoggedin  = FALSE;
	static $isVIP		= FALSE;
	static $isAdmin		= FALSE;

	static $id			= 0;
	static $username 	= '';
	static $password	= '';
	static $email		= '';
	static $ip			= '127.0.0.1';

	static $title		= '';
	static $url			= 'http://';
	static $category	= '1';
	static $description	= '';
	static $details		= '';
	static $banner		= 'http://';

	static $in			= 0;
	static $out			= 0;
	static $intotal		= 0;
	static $outtotal	= 0;
	
	static function Build()
	{
		if(isset($_GET['logout']))
		{
			$_SESSION['isLoggedin'] = FALSE;
		}

		if(isset($_SESSION['isLoggedin']))
		{
			if($_SESSION['isLoggedin'] === TRUE)
			{
				if(isset($_SESSION['username']) && isset($_SESSION['password']))
				{
					$username = $_SESSION['username'];
					$password = $_SESSION['password'];

					self::login($username, $password);
				}
			}
		}
	}
	
	static function register($username, $password)
	{
		DB::query("SELECT id FROM top_topsites WHERE username = '$username' LIMIT 1");
		
		if(DB::num_rows() < 1)
		{
			$encrypted = md5($username . $password);
			$ip = (getenv('HTTP_X_FORWARDED_FOR')) ? getenv('HTTP_X_FORWARDED_FOR') : getenv('REMOTE_ADDR');
			
			DB::query("INSERT INTO topsites SET username = '$username', password = '$encrypted', ip = '$ip'");
			self::login($username, $password);
			return true;
		}
		
		return false;
	}
	
	static function login($username, $password, $encrypt = TRUE)
	{
		if(!empty($username) && !empty($password))
		{
			$encrypted = ($encrypt == TRUE) ? md5($username . $password) : $password;
			DB::select('top_topsites', "username = '$username' AND password = '$encrypted'", '1');

			if(DB::num_rows() > 0)
			{
				$user = Db::fetch_row();

				foreach($user as $k => $v)
				{
					if(isset(self::$$k))
					{
						self::$$k = $v;
					}
					
					if($k = 'password')
					{
						continue;
					}
					$$k = $v;
				}

				self::$isLoggedin = TRUE;
				self::$ip		  = $_SERVER['REMOTE_ADDR'];

				$_SESSION['isLoggedin'] = TRUE;
				$_SESSION['username']	= $username;
				$_SESSION['password']	= $password;
				return true;
			}
		}
		return false;
	}
	
	static function save($id, $user)
	{
		$i = 0;
		$query = 'UPDATE top_topsites SET ';

		foreach($user as $k => $v)
		{
			$i++;
			if(isset(self::$$k))
			{
				$query .= $k . ' = \'' . $v . '\'';
				$query .= ($i != count($user)) ? ', ' : ' ';
			}
		}

		$query .= 'WHERE id = \''.$id.'\' LIMIT 1';
		DB::query($query);
	}
}