<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Language" content="en-us" />
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />

<meta name="description" content="Need traffic to your game website? join our high traffic top list we guarantee you more traffic for free.">
<meta name="keywords" content="Ultima online, ragnarok online, top list, game, games, lineage, world of warcraft, warcraft 3, starcraft, diablo 2, star wars, counter strike, game toplist, lineage 2, game news, game sites, gaming sites, links, 100, 200">
<meta name="author" content="SEOMinds LTD">
<meta name="revisit-after" content="15 days">
<meta name="robots" content="index,follow">
<meta name="googlebot" content="index,follow">
<title><?php echo Config::item('title'); ?></title>

<link href="templates/Xtreme/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<!--
    function popup(name) {
	   if(name == 'Create a free server')
	   {
			var e = document.getElementById('serverinfo');
	        if(e.style.display == 'block')
	          e.style.display = 'none';
	        else
	          e.style.display = 'block';
	   }
    }
//-->
</script>
</head>
<body>


<div id="serverinfo" class="serverinfo" style="display: none;">
	<div style="background-image: url(templates/Xtreme/images/middlebtop.gif); height: 35px;">
		<div style="float: right; margin: 5px 2px 2px 2px;"><a href="#" onclick="popup('Create a free server');"><b><span style="color: #FFFFFF;">Close</span></b></a></div>
		<div style="margin: 5px 2px 2px 2px; color: #FFFFFF; padding-left: 7px;"><b>What hardware/system do you need when creating a free server?</b></div>
	</div>

	<div style="width: 640px; margin-left: 20px; margin-right: 20px;">
	<br />
	<b>How to create your own dedicated game server</b><br />
	I created this guide because I received several emails everyday from people who are concerned about their server hardware / hosting hardware. 
	I'm having a hard time answering all emails there for I'm creating this guide which I will continue to build on as time passes.<br />
	<br />
	When you have choose a game emulator and are ready to start your own dedicated server. You should ask 
	yourself one question though, are you going to host at home or are you going to rent a server at a data center?
	A <b>Data-Center</b> has the technology to host any kind of server, isnt one server enough? then theres server balancing built in a server-cluster.<br />
	You can even rent your own rack server if you want.<br />
	So what kind of hardware should you use? Well don't go and buy expensive server processors like Xeon or Opterons series (Dual Core). 
	These processors are dual core and are for servers but it doesn't mean it's the best right? But there are cheaper but better <strong>dual core</strong> processors/CPU, 
	I would recommend that you have a look at Core 2 Duo (Dual core) or Kentsfield core which is a Quad-Core processor, both are released by Intel. 
	How much RAM (memory) do you need? Well I would start with 2 GB RAM at start, and then upgrade when it's needed.
	<br /><br />
	<b>Why pick Dual-Core or even Quad-Core servers?</b><br />
	It's a new era, Dual-Core and Quad-Core are today's news. This is a must. You will be able to run both the server emulator and webpage on the same server 
	without any kind of problems. If you are going for a mmorpg server there's plenty of emulators which supports multithreading. But mmorpg servers hold sometimes 
	over 1000 players which require a huge CPU/processor power. 
	That's why you should pick at least a Dual-Core for your dedicated server but looking at the prices it tells me i should go with a Quad-Core CPU. 
	<br /><br />
	<b>Why a gaming server?</b><br />
	Especially mmorpg server's takes a lot of bandwidth, FPS servers are not as bandwidth hungry as mmorpg servers due to the low amount of players. 
	The best with having the gaming server at a hosting company is that it usually has up to 10 different ISPs and up to 1000Mbit per line which will 
	give your players an amazing gaming experience. They also have the latest server hardware technologies, so finding a Quad-Core, Core 2 Duo or the 
	AMD X2 or Opteron series (Both Dual-Cores) should not be a problem. Most servers have RAID or using fast SAS storage (SCSI discs). 
	<br /><br />
	A great Web hosting company is <a href="http://www.tkqlhce.com/click-3098112-10410811" target="_top">HostGator</a>
	<img src="http://www.ftjcfx.com/image-3343734-10410811" width="1" height="1" border="0"/><br />
	<b>Host Gator is one of the biggest web hosting companies around with excellent hosting and pricing.</b>
	<br />
	<br />
	when looking for server emulators please try to search on Google... I will try to continue updating this guide when i have more time.
	<br />
	<br />
	Best Regards<br />
	XtremeTop100 staff<br /><br />

	</div>
</div>
<div id="top">

	<div id="topb">
		<div id="logo"></div>
		<div id="topdh">
			<?php $first = TRUE; ?>
			<?php foreach(navigation() as $nav):?>
				<?php if($first == FALSE): ?>
					&nbsp;<img src="templates/Xtreme/images/dh.jpg" align="absmiddle" />
				<?php endif; ?>
				<a href="<?php echo $nav['link']; ?>" onclick="popup('<?php echo $nav['name']; ?>');" class="bai"><?php echo $nav['name']; ?></a>
				<?php $first = FALSE; ?>
			<?php endforeach; ?>
			<?php if(User::$isAdmin == TRUE): ?>
				&nbsp;<img src="templates/Xtreme/images/dh.jpg" align="absmiddle" /> <a href="?acp" class="bai">Admin CP</a>
			<?php endif; ?>
		</div>
	</div>
</div>
<div id="middle">
	<div id="middlea">
		<div id="middleabg">Categories</div>		
			<?php $i = 0; ?>
			<?php $count = count(categories()); ?>
			<?php foreach(categories() as $cat): $i++; ?>
				<div id="middleabg<?php echo ($i == $count) ? 'd' : 'c'; ?>">
					<a href="?index&category=<?php echo $cat['id']; ?>" class="hei"><?php echo $cat['name']; ?></a>
				</div>
			<?php endforeach; ?>
		<br /><br /><br /><br /><br />
	</div>
<div id="middleb">