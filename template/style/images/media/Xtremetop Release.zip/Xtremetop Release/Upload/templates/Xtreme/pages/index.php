<br /><div id="middleba">
	<?php if(Config::item('adsense_id') != 0): ?>
		<script type="text/javascript"><!--
		google_ad_client = "pub-<?php echo Config::item('adsense_id'); ?>";
		google_ad_width = 728;
		google_ad_height = 90;
		google_ad_format = "728x90_as";
		google_ad_type = "text";
		google_ad_channel = "7395497989";
		google_color_border = "FFFFFF";
		google_color_bg = "FFFFFF";
		google_color_link = "0000FF";
		google_color_url = "000000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
	<?php endif; ?>
		
		</div><br /><br /><div id="middleba">Top 100 Game sites</div><div id="middlebb">Private servers, free servers, game servers, powerful servers</div><br /><br /><br />

<script language="JavaScript">
<!-- 
if (window != top) { top.location.href = location.href; } 
-->
</script>
<script language=JavaScript><!--
	function changecat(newcat) {
	    exit=false;
	    site = "index.php?cid="+(newcat);
	    if (newcat!=0) {
		top.location.href=site;
	    } else {
		top.location.href="index.php";
	    }
	}
	-->
</script>

<?php foreach(Page::sites() as $site):?>
	<div id="xuxian"></div>
	<?php if($site['isVIP'] == TRUE): ?>
		<div class="box2">
			<table cellpadding="5" cellspacing="0" border="0" width="736px" align="center">
				<tr>
				<td class="number" rowspan="2"><b><?php echo $start; ?><br /><span style="float: center; font-size: 11px"><a href="?detail=<?php echo $site['id']; ?>" style="text-decoration: none;">Details</a>
					<?php if(can_edit($site)): ?>
						<br><a href='?ucp=<?php echo $site['id']; ?>' style="text-decoration: none;">Edit</a>
					<?php endif;?>
					</span></b></td>
				<td class="mid" rowspan="2">
					<?php if(show_banner($site)): ?>
						<a target="_blank" href="?out=<?php echo $site['id']; ?>" rel="nofollow"><img src="<?php echo $site['banner']; ?>" width="468" height="60" border="0"></a>
					<?php endif; ?>
					<br />
					<div class="midtext2">
			 			<span class="hd1">
							<a target="_blank" href="?out=<?php echo $site['id']; ?>" style="text-decoration: none;" rel="nofollow"><?php echo $site['title']; ?></a>
						</span>
						<br />
						<?php echo $site['description']; ?>
						<br /><br />
				    </div>
			    </td>
				<td class="stats1"><br /><br /><b><span style="font-size: 12px; color: #000000;">IN</span></b><br /> <span><?php echo $site['in']; ?></span></td>
				<td class="stats"><br /><br /><b><span style="font-size: 12px; color: #000000;">OUT</span></b><br /> <span><?php echo $site['out']; ?></span>
				</td>
				</tr>
				 <tr>
				<td colspan="2"></td>
			 	 </tr>
			</table>
			</div>
	<?php else: ?>
					<div id="middlebd">
					<div id="middlebda"><?php echo $start; ?><br /></div>

						<div id="middlebdb">
							<div id="middlebdba"><a href="?out=<?php echo $site['id']; ?>" class="lan" target="_blank" rel="nofollow"><?php echo $site['title']; ?></a></div>

							<div id="middlebdbb"><span id="details"><a href="?detail=<?php echo $site['id']; ?>" style="text-decoration: none;">Details</a><?php if(User::$id == $site['id'] || User::$isAdmin == TRUE): ?><br><a href="?ucp=<?php echo $site['id']; ?>" style="text-decoration: none;">Edit</a><?php endif; ?></span><?php echo $site['description']; ?></div>
						</div>
							<div id="middlebdc">
								<div id="middlebdca">IN</div>
								<div id="middlebdcb"><?php echo $site['in']; ?></div>
							</div>
							<div id="middlebdc">
								<div id="middlebdca">OUT</div>
								<div id="middlebdcC"><?php echo $site['out']; ?></div>
							</div>
					</div>
	<?php endif; ?>
	<?php $start++; ?>
<?php endforeach; ?>


<div id="middlebe">
	<a href="?<?php echo (isset($current)) ? $current : 'index'; ?>&category=<?php echo $category; ?>">1-50</a> | <a href="?<?php echo (isset($current)) ? $current : 'index'; ?>=50&category=<?php echo $category; ?>">50-100</a> | <a href="?<?php echo (isset($current)) ? $current : 'index'; ?>=100&category=<?php echo $category; ?>">100-150</a> | <a href="?<?php echo (isset($current)) ? $current : 'index'; ?>=150&category=<?php echo $category; ?>">150-200</a>
</div>