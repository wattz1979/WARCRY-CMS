<h1>ACP</h1>
<br>
<small><?php echo $message; ?></small>

<h2>Modules</h2>

<?php if(count($modules)  > 0): ?>
<table>
	<tr>
		<td><b><small>Module</small></b></td>
		<td style='padding-left:50px;'><b><small>Description</small></b></td>
		<td style='padding-left:50px;'><b><small>Pages</small></b></td>
		<td style='padding-left:50px;'><b><small>Status</small></b></td>
	</tr>
<?php foreach($modules as $module):?>
	<tr>
		<td><small><?php echo $module['name']; ?></small></td>
		<td style='padding-left:50px;'><small><?php echo $module['description']; ?></small></td>
		<td style='padding-left:50px;'><small><?php echo $module['pages']; ?></small></td>
		<td style='padding-left:50px;'><small><?php echo $module['status']; ?></small></td>
	</tr>
<?php endforeach; ?>
</table>
<?php else: ?>
<small>No modules</small>
<?php endif; ?>
<br>