<?php
/***************************************************************************
 *                                membership.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Subpage
{
	static function Build()
	{
		if(User::$isLoggedin != TRUE)
		{
			redirect('login');
		}
		
		if(isset($_POST['pay']))
		{
			$username = User::$username;
			$pp_email = DB::safe($_POST['pp_email']);
			DB::query("INSERT INTO top_payment_requests SET username = '$username', pp_email = '$pp_email'");

			$data = array(
				'email' => Config::item('paypal_email'),
			
				'base_url'	=> Config::item('siteurl'),
				'return_url' => Config::item('siteurl') . '?edit=membership',
				'ipn_url'	=> Config::item('siteurl') . 'system/paypal_ipn.php',
			
				'payment' => 15 * $_POST['months']);

			Load::view('paypal_redirect', $data);
		}
		
		else
		{
			$payments = array();
			$username = User::$username;

			$query  = "SELECT a.data, a.success, a.error_message FROM top_payments AS a, top_payment_requests AS b ";
			$query .= "WHERE b.username = '$username' AND a.email = b.pp_email";
			DB::query($query);

			if(DB::num_rows() > 0)
			{
				foreach(DB::fetch_array() as $k => $array)
				{
					$payment = unserialize($array['data']);
					$reason  = $array['error_message'];
					$payments[] = array(
						'item' => 'Monthly Payment',
						'success' => ($array['success'] == '1') ? 'Successful' : 'Failed ('.$reason.')',
						'pay_date' => $payment['payment_date']);
				}

			}

			$days_left = 0;
			if(User::$isVIP > 0)
			{
				$months_left = ((User::$isVIP - 1) + (time_until_reset() / 2629743));
				$days_left = ceil($months_left * 30);
			}

			Load::view('ucp/membership', array('days_left' => $days_left, 'payments' => $payments));
		}
	}
}