<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	
	<title>TopsiteCMS &#9679; Admin Control Panel</title>
	
    <style type="text/css" media="all">
		@import url("templates/Xtreme/css/acp_style.css");
		@import url("templates/Xtreme/css/jquery.wysiwyg.css");
		@import url("templates/Xtreme/css/facebox.css");
		@import url("templates/Xtreme/css/visualize.css");
		@import url("templates/Xtreme/css/date_input.css");
    </style>
	
	<!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=7" /><![endif]-->
	<!--[if lt IE 8]><style type="text/css" media="all">@import url("templates/Xtreme/css/ie.css");</style><![endif]-->
	<!--[if IE]><script type="text/javascript" src="templates/Xtreme/js/excanvas.js"></script><![endif]-->
	
	<script type="text/javascript" src="templates/Xtreme/js/jquery.js"></script>
	<script type="text/javascript" src="templates/Xtreme/js/jquery.img.preload.js"></script>
	<script type="text/javascript" src="templates/Xtreme/js/jquery.filestyle.mini.js"></script>
	<script type="text/javascript" src="templates/Xtreme/js/jquery.wysiwyg.js"></script>
	<script type="text/javascript" src="templates/Xtreme/js/jquery.date_input.pack.js"></script>
	<script type="text/javascript" src="templates/Xtreme/js/facebox.js"></script>
	<script type="text/javascript" src="templates/Xtreme/js/jquery.visualize.js"></script>
	<script type="text/javascript" src="templates/Xtreme/js/jquery.select_skin.js"></script>
	<script type="text/javascript" src="templates/Xtreme/js/ajaxupload.js"></script>
	<script type="text/javascript" src="templates/Xtreme/js/jquery.pngfix.js"></script>
	<script type="text/javascript" src="templates/Xtreme/js/custom.js"></script>

</head>

<body>
	<div id="hld">
		<div class="wrapper">		<!-- wrapper begins -->
	
			<div id="header">
				<div class="hdrl"></div>
				<div class="hdrr"></div>