<?php
/***************************************************************************
 *                                contact.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Page
{
	static $message = array(
		'color'		=> 'red',
		'message'	=> '');

	static function Build()
	{
		if(isset($_POST['submit']))
		{
			$message = self::send();
		}

		Load::view('contact', self::$message);
	}
	
	static function send()
	{
		if(empty($_POST['email']))
		{
			return self::$message['message'] = 'We need an email to reply to you';
		}
		
		if(empty($_POST['message']))
		{
			return self::$message['message'] = 'Your message cannot be blank';
		}

		if($_POST['antispam'] != 'xtreme')
		{
			return self::$message['message'] = 'You misspelled `xtreme`';			
		}
		
		self::$message['color'] = 'green';
		self::$message['message'] = 'Your message has been sent';
		DB::query("INSERT INTO top_messages SET name = '{$_POST['name']}', email = '{$_POST['email']}', message = '{$_POST['message']}'");
	}
}