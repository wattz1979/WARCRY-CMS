


<br />
			<div id="boxy"><center><h2><?php echo $title; ?>!</h2></center></div>
			<br /><br /><a target="_blank" href="?out=<?php echo $id; ?>"><img src="<?php echo $banner; ?>" width="468" height="60" border="0"></a><br />
	
			<div id="middlebdbb2">
			<a href="?out=<?php echo $id; ?>" target="_bank"><span style="color: blue; font-weight: bold;"><?php echo $title; ?></span></a><br />
			<?php echo $description; ?><br /><br />
			<b>Link</b> - <a href="?out=<?php echo $id; ?>" target="_bank"><span style="color: blue;"><?php echo $title; ?></span></a>
			</div>
			<br />
			<script type="text/javascript"><!--
			google_ad_client = "pub-<?php echo Config::item('adsense_id'); ?>";
			//728x90, skapad 2008-01-22
			google_ad_slot = "2219061823";
			google_ad_width = 728;
			google_ad_height = 90;
			//--></script>
			<script type="text/javascript"
			src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
			</script>
	
	
	
			</span>
			<div id="xuxian"></div><br /><br />
	
	
			<strong><span style="font-size: 11pt; font-family: Verdana, Arial, Helvetica, sans-serif;"><div id="middlebda2"><?php echo $title; ?> Information:</div></span></strong>
			<div style="padding-left: 12px; padding-top: 12px;">
				<?php if($details == ''): ?>
					This user has not updated the site details.
				<?php else: ?>
					<?php echo bbcode($details); ?>
				<?php endif; ?>
			</div><br /><br />



	<div id="xuxian"></div><br /><br />



	<strong><span style="font-size: 11pt; font-family: Verdana, Arial, Helvetica, sans-serif;"><div id="middlebda2"><?php echo $title; ?> Images:</div></span></strong>
	<div style="padding-left: 12px; padding-top: 12px;">
		<?php if($screenshot_count == 0): ?>
			This user has not uploaded any images.
		<?php else: ?>
			<table>
			<?php foreach($screenshots as $s): ?>
				<tr>
					<td><img src="<?php echo $s['link']; ?>"></td>
				</tr>
			<?php endforeach; ?>
			</table>
		<?php endif; ?>
	</div>