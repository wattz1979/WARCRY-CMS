<?php
/***************************************************************************
 *                                screenshots.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Subpage
{
	static function Build()
	{
		if(User::$isLoggedin != TRUE)
		{
			redirect('login');
		}
		
		if(isset($_GET['remove']) && is_numeric($_GET['remove']))
		{
			DB::query("DELETE FROM top_screenshots WHERE id = '{$_GET['remove']}' LIMIT 1");
		}
		
		if(isset($_POST['submit']))
		{
			if(!empty($_POST['image']))
			{
				$id = User::$id;
				$image = DB::safe($_POST['image']);
				DB::query("INSERT INTO top_screenshots SET site_id = '$id', link = '$image'");
			}
		}

		DB::select('top_screenshots', 'site_id = \''.User::$id.'\'');
		$data = array('screenshot_count' => DB::num_rows(), 'screenshots' => DB::fetch_array());

		Load::view('ucp/screenshots', $data);
	}
}