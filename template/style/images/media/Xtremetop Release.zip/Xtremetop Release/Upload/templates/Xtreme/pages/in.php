<div align="left">
			<font face="Verdana" color="black" size="3"><small>
			<br />
			<font face="Verdana" color="black" size="5"<small><center><b>Vote for <?php echo $sitename; ?></b></font></small> 
			<p>
			<form method="POST" action="?in=<?php echo $id; ?>" style="display: inline;">
		
			<p style="text-align: center">
				<?php echo recaptcha_get_html($publickey, $error); ?>
				<br /><input type="submit" value="Vote for <?php echo $sitename; ?>" name="vote"><br /><br />
<table border="0" width="100" cellspacing="0" cellpadding="0" id="table4">
	<tr>
	<td colspan="4">
	<script type="text/javascript"><!--
	google_ad_client = "pub-8786108981524121";
	google_ad_width = 728;
	google_ad_height = 90;
	google_ad_format = "728x90_as";
	google_ad_type = "text";
	google_ad_channel ="";
	google_color_border = "FFFFFF";
	google_color_bg = "FFFFFF";
	google_color_link = "0000FF";
	google_color_text = "000000";
	google_color_url = "000000";
	//--></script>
	<script type="text/javascript"
	  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
	</script>

	</td>
	</tr>
</table>
	<font face="Verdana" color="black" size="2"><br /><br /><br />[Please click <a href="?index">here</a> if you have been tricked.] Voting is once every 12 hoursIn/Out resets every 30 days<br /><br /><br /><br />
</form>
</div>