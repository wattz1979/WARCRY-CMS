<?php
/***************************************************************************
 *                                edit.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Page
{
	static function Build($page)
	{
		if(User::$isLoggedin != TRUE)
		{
			redirect('login');
		}

		$pages = array('details', 'password', 'screenshots', 'membership', 'htmlcode');
		if(!in_array($page, $pages))
		{
			redirect('ucp');
		}

		else
		{
			$path = 'templates/Xtreme/modules/ucp/';
			if(file_exists($path . $page . '.php'))
			{
				include $path . $page . '.php';
				Subpage::Build();
			}
		}
	}
}