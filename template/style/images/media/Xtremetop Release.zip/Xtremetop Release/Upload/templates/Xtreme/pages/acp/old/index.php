<div id="middlebtop">ACP</div>
<div id="middlebtopa">
	<small>
		<span style="font-size: 12px; font-family:Verdana;">
			<small><?php echo $message; ?></small>
			<h2>Main Settings</h2>
			<form method='post' action='?acp/index'>
			<table>
				<tr>
					<td><small>Site's Title:</small></td>
					<td><input type='text' name='title' value="<?php echo Config::item('title'); ?>"></td>
				</tr>
				<tr>
					<td><small>Template:</small></td>
					<td>
						<select name='template'>
							<option value='<?php echo $default; ?>' selected='selected'><?php echo $default; ?></option>
							<?php foreach($templates as $template):?>
								<option value='<?php echo $template; ?>'><?php echo $template?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
			</table>

			<h2>Database Connection Settings</h2>
			<table>
				<tr>
					<td><small>Hostname:</small></td>
					<td><input type='text' name='hostname' value='<?php echo Config::item('hostname'); ?>'></td>
				</tr>
				<tr>
					<td><small>Username:</small></td>
					<td><input type='text' name='username' value='<?php echo Config::item('username'); ?>'></td>
				</tr>
				<tr>
					<td><small>Password:</small></td>
					<td><input type='text' name='password' value='<?php echo Config::item('password'); ?>'></td>
				</tr>
				<tr>
					<td><small>Database name:</small></td>
					<td><input type='text' name='database' value='<?php echo Config::item('database'); ?>'></td>
				</tr>
			</table>

			<h2>Topsite Pagination</h2>
			<table>
				<tr>
					<td><small>Sites per Page:</small></td>
					<td><input type='text' name='sites_per_page' value='<?php echo Config::item('sites_per_page'); ?>'></td>
				</tr>
				<tr>
					<td><small>Maximum Pages:</small></td>
					<td><input type='text' name='max_pages' value='<?php echo Config::item('max_pages'); ?>'></td>
				</tr>
			</table>

			<h2>Brute Force Prevention</h2>
			<table>
				<tr>
					<td><small>Max Login Attempts:</small></td>
					<td><input type='text' name='max_attempts' value='<?php echo Config::item('max_attempts'); ?>'></td>
				</tr>
				<tr>
					<td><small>Login Prevention Timer:</small></td>
					<td><input type='text' name='prevention_timer' value='<?php echo Config::item('prevention_timer'); ?>'></td>
				</tr>
			</table>

			<input type='submit' name='edit' value='Save'>
			</form>
		</span>
	</small>
</div>