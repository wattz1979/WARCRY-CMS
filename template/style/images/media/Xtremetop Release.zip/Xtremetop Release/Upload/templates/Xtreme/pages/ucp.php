<div id="middlebtop">Edit account</div>
<div id="middlebtopa">
<small>
<span style="font-size: 12px; font-family:Verdana;">



<ul id="thicktabs">
	<li><a href="?ucp" id="leftmostitem">Main edit</a></li>
	<li><a href="?edit=details">Website details</a></li>
	<li><a href="?edit=screenshots">Upload screenshots</a></li>
	<li><a href="?edit=membership">Gold membership</a></li>	
	<li><a href="?edit=htmlcode">Get HTML code</a></li>
	<span style="float:right; font-size: 13px; color: red;"><li><a href="?logout">Logout!</a></li></span>
</ul>
<br style="clear: left" />



<br />

		<div style="background-color: #fbfaef; padding-top: 1px; padding-bottom: 5px; padding-right: 8px; border-right-width: 1pt; border-bottom-width: 1pt; border-top-width: 1pt; border-left-width: 1pt; border-right-style: solid; border-bottom-style: solid; border-top-style: solid; border-left-style: solid; border-right-color: #BFBBBA; border-bottom-color: #BFBBBA; border-left-color: #BFBBBA; border-top-color: #BFBBBA;">
		<ul>
		<?php if($message != 'You can edit your settings here.'):?>
		<?php echo $message; ?><br />
		<?php endif; ?>
		<li>Your account/website information may take up to five minutes to update on the toplist.<br /></li>
		<li>You username cannot be edited. If you wish to change it, please contact the admin.</li>
		</ul>
		</div>

			<form action="?ucp=<?php echo $id; ?>" method="post">
			<table border="0" width="734" cellspacing="4" cellpadding="4">
					<tr>
						<td valign="top" colspan="2"><i><b>
						<font size="3" color="#3399FF">Edit account:</font></b></i></td>
					</tr>

					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Username:</font></b></td>
						<td valign="top">
						<?php echo $username; ?></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Password:</font></b></td>
						<td valign="top">
						<a href="?edit=password">Change it here</a></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Email:</font></b></td>
						<td valign="top">
						<input type="text" name="email" size="37" value="<?php echo $email; ?>"></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Site Title:</font></b></td>
						<td valign="top">
						<input type="text" name="title" size="37" value="<?php echo $title; ?>"><font face="Verdana" size="2"><b>
						</b>Max length 40.</font></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Site URL:</font></b></td>
						<td valign="top">
						<input type="text" name="url" size="37" value="<?php echo $url; ?>"><font face="Verdana" size="2"><b>
						</b>Url needs to begin with http://.</font></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Banner URL</font></b></td>
						<td valign="top">
						<input type="text" name="banner" size="37" value="<?php echo $banner; ?>"><font face="Verdana" size="2"> 
						No banner? then keep the http:// part.</font></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Site Description:</font></b></td>
						<td valign="top">
						<textarea rows="6" name="description" cols="28"><?php echo $description; ?></textarea><font face="Verdana" size="2"> 
						Max length 300.</font></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Site Category:</font></b></td>
						<td valign="top">
						<select name="category">
							<?php foreach(categories() as $c): ?>
								<option value="<?php echo $c['id']; ?>" <?php if($c['id'] == $category) echo 'selected=\'selected\''; ?>>
									<?php echo $c['name']; ?>
								</option>
							<?php endforeach; ?>
						</select>
						</td>
					</tr>
					<tr>
						<td width="147">&nbsp;</td>
						<td><input type="submit" value="Update my website!" name="edit"></td>
					</tr>
					<tr>
						<td width="147">&nbsp;</td>
						<td>&nbsp;</td>
					</tr>
				</table>
		

			</form>


	</span>
	</small>
	</div>
