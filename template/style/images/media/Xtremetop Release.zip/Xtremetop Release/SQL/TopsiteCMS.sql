SET NAMES latin1;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE `top_actions` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `siteid` int(5) NOT NULL,
  `ip` char(255) NOT NULL,
  `action` tinyint(1) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `top_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

insert into `top_categories` values('1','World of Warcraft');
	
CREATE TABLE `top_messages` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `top_navigation` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

insert into `top_navigation` values('1','Sites','?index'),
 ('2','Add Site','?register'),
 ('3','Edit Account','?ucp'),
 ('4','Last submitted sites','?last'),
 ('5','Gold Membership','?edit=membership'),
 ('6','Create a free server','#'),
 ('7','Contact','?contact');

CREATE TABLE `top_payment_requests` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `pp_email` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `top_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txn_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `error_message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `top_reset_request` (
  `username` varchar(255) NOT NULL,
  `serial` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `top_reset_timer` (
  `reset_timer` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

insert into `top_reset_timer` values('1280371090');
	
CREATE TABLE `top_screenshots` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `site_id` int(5) NOT NULL,
  `link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1  DEFAULT CHARSET=latin1;

CREATE TABLE `top_topsites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `isVIP` int(1) NOT NULL DEFAULT '0',
  `isAdmin` int(1) NOT NULL DEFAULT '0',
  `ip` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `email` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `banner` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `details` text NOT NULL,
  `in` int(11) NOT NULL DEFAULT '0',
  `intotal` int(11) NOT NULL DEFAULT '0',
  `out` int(11) NOT NULL DEFAULT '0',
  `outtotal` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

SET FOREIGN_KEY_CHECKS = 1;
