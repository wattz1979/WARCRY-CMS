			<div id="footer">
				<p class="right">powered by <a href="http://thepingue.com">TopsiteCMS</a> v1.0</p>
			</div>
		</div>						<!-- wrapper ends -->	
	</div>		<!-- #hld ends -->
</body>
</html>