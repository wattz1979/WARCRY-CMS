<div id="middlebtop">Gold membership</div>
<div id="middlebtopa">
<small>
<span style="font-size: 12px; font-family:Verdana;">


<ul id="thicktabs">
	<li><a href="?ucp" id="leftmostitem">Main edit</a></li>
	<li><a href="?edit=details">Website details</a></li>
	<li><a href="?edit=screenshots">Upload screenshots</a></li>
	<li><a href="?edit=membership">Gold membership</a></li>
	<li><a href="?edit=htmlcode">Get HTML code</a></li>
	<span style="float:right; font-size: 13px; color: red;"><li><a href="?logout">Logout!</a></li></span>
</ul>
<br style="clear: left" />
<br />

		<div id="boxy">
		<ul>	
		<li>You have <?php echo $days_left; ?> days left on your gold membership.</li><br />
		</ul>
		</div>
		<br />
		<br />

			<b>Gold Membership</b><br />
			For a flat fee of 15$ per month, your website can have a banner shown in its listing. This has been found to dramatically increase the number of hits out.
			To order a banner in listing immediately please type in your site id below. <br />
			<br />
			If payment is successful it will show your banner a few minutes after payment.<br />
			<b>Please note that it sometimes have a delay up to 48 hours after payment, this is due to PayPals server.</b>
			<br />
			<br />
			Choose the number of months you want to display your banner and click on the button [Secure Payment via PayPal] to Pay your Gold Membership.<br />
			<br />
			<form name="countform" method="post" action="?edit=membership">
			<b>Paypal</b> Email: <input type="text" name="pp_email" size="30">
			<br />
			<br />
			<select name="months">
			  <option value="1" selected>1 month</option>
			  <option value="2">2 months</option>
			  <option value="3">3 months</option>
			  <option value="4">4 months</option>
			  <option value="5">5 months</option>
			  <option value="6">6 months</option>
			</select>
			
			<input type="submit" value="Secure Payment via PayPal" name="pay">
			</form>
				
				<br />
				
					<table border="0" width="711" cellpadding="2">
						<tr>
							<td colspan="4" bgcolor="#B9B7A6">
							<table border="0" width="100%" cellspacing="1">
								<tr>
									<td width="282"><font color="#FFFFFF"><b>Item</b></font></td>
									<td width="196"><font color="#FFFFFF"><b>Status</b></font></td>
									<td><p align="center"><font color="#FFFFFF"><b>Pay Date (Pacific Time)</b></font></td>
								</tr>
							</table>
							</td>
						</tr>

<?php if(count($payments) > 0): ?>
	<?php foreach($payments as $p): ?>
		<tr>
			<td width="282"><?php echo $p['item'];?></td>
			<td width="196"><?php echo $p['success']; ?></td>
			<td><p align="center"><?php echo $p['pay_date']; ?></p></td>
		</tr>
	<?php endforeach; ?>	
<?php else: ?>
<tr><td>There was no payments found...</td></tr>
<?php endif;?>
</table>


<br />
</span>
</small>
</div>