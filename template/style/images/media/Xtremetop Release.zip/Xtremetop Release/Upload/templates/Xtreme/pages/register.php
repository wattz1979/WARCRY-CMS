<div id="middlebtop">Rules for joining</div>
<div id="middlebtopa">
	<small>
		<span style="font-size: 12px; font-family:Verdana;">
		<div style="background-color: #fbfaef; padding-top: 1px; padding-bottom: 5px; padding-right: 8px; border-right-width: 1pt; border-bottom-width: 1pt; border-top-width: 1pt; border-left-width: 1pt; border-right-style: solid; border-bottom-style: solid; border-top-style: solid; border-left-style: solid; border-right-color: #BFBBBA; border-bottom-color: #BFBBBA; border-left-color: #BFBBBA; border-top-color: #BFBBBA;">
		<ul>
		
		<li><b>We dont allow Maple Story websites, any websites regarding Maple Story will be removed.</b>
		<li><b>We dont allow Lineage websites, any websites regarding Lineage will be removed.</b>
		<li>We no longer allow websites that contains hack or cracks, or any kind of software that manipulates any kind of programs.<br />
		<li>NO Script's allowed for incoming Hit's.<br />
		<li>The Counter's will be reset periodicallyIn/Out resets every 30 days.<br />
		<li>Cheating will get you banned for good.<br />
		<li>Any kind of force voting is illegal... no one should have to vote before entering your website, anyone using will have their account cancelled without warning!<br />
		<li>You agree that the webmaster of this website have the right to remove, edit or move any website at any time. As a user you agree to any information you have entered above being stored in a database. While this information will not be disclosed to any third party without your consent the webmaster.<br />
		</ul>
		</div>
		<br /><br />
			<form action="?register" method="post">
			<i><b><font size="3" color="#3399FF">Registration</font></b></i><br><br>
			<?php echo $message; ?>
			<table border="0" width="734" cellspacing="4" cellpadding="4">
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Username:</font></b></td>
						<td valign="top">
						<input type="text" name="username" size="37" value="<?php echo $username; ?>"></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Password:</font></b></td>
						<td valign="top">
						<input type="password" name="password" size="37" value="<?php echo $password; ?>"></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Confirm Password:</font></b></td>
						<td valign="top">
						<input type="password" name="confirm" size="37" value="<?php echo $confirm; ?>"></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Email:</font></b></td>
						<td valign="top">
						<input type="text" name="email" size="37" value="<?php echo $email; ?>"></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Site Title:</font></b></td>
						<td valign="top">
						<input type="text" name="title" size="37" value="<?php echo $title; ?>"><font face="Verdana" size="2"><b>
						</b>Max length 40.</font></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Site URL:</font></b></td>
						<td valign="top">
						<input type="text" name="url" size="37" value="<?php echo $url; ?>"><font face="Verdana" size="2"><b>
						</b>Url needs to begin with http://.</font></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Banner URL</font></b></td>
						<td valign="top">
						<input type="text" name="banner" size="37" value="<?php echo $banner; ?>"><font face="Verdana" size="2"> 
						No banner? then keep the http:// part.</font></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Site Description:</font></b></td>
						<td valign="top">
						<textarea rows="6" name="description" cols="28"><?php echo $description; ?></textarea><font face="Verdana" size="2"> 
						Max length 300.</font></td>
					</tr>
					<tr>
						<td width="147" valign="top"><b>
						<font face="Verdana" size="2">Site Category:</font></b></td>
						<td valign="top">
						<select name='category'>
							<?php foreach(Page::categories() as $cat):?>
							<option value='<?php echo $cat['id']; ?>' <?php if($cat['id'] == $category) echo 'selected=\'selected\''; ?>><?php echo $cat['name']; ?></option>
							<?php endforeach; ?>

						</select>
						</td>
					</tr>
					<tr>
						<td width="147">&nbsp;</td>
						<td><input type="submit" value="Add my website!" name="register"></td>
					</tr>
					<tr>
						<td width="147">&nbsp;</td>
						<td>&nbsp;</td>
					</tr>
				</table>
			</form>
		</span>
	</small>
</div>