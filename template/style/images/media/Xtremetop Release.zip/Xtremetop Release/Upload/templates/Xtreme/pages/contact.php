<div id="middlebtop">Contact</div>
<div id="middlebtopa">
<small>
<span style="font-size: 12px; font-family:Verdana;">

<div style="background-color: #fbfaef; padding-top: 1px; padding-bottom: 5px; padding-right: 8px; border-right-width: 1pt; border-bottom-width: 1pt; border-top-width: 1pt; border-left-width: 1pt; border-right-style: solid; border-bottom-style: solid; border-top-style: solid; border-left-style: solid; border-right-color: #BFBBBA; border-bottom-color: #BFBBBA; border-left-color: #BFBBBA; border-top-color: #BFBBBA;">
<ul style="LINE-HEIGHT: 1.5em">
You can contact us for whatever reason, just fill out this forum and click send. Before you submit note the following:<br /><br />


  <li>Want to add your website to the toplist? <a href="?register">Join Here</a>
  <li><b>Forgot your password?</b> <a href="?forgot">Click here</a>. Enter in your username and your password will be emailed to you.
  <li>We do <b>NOT</b> offer support on the linked websites on the toplists. We only link to them. If a site is not working, contact them, not us.</li>
</ul>
</div>

                <b><form method="post" action="?contact">
				<b style="color:<?php echo $color; ?>;"><?php echo $message; ?></b>
				<br />
		Name:<br /><input name="name" type="text" size="30" maxlength="40" /><br /><br />
		Email:<br /><input name="email" type="text" size="30" maxlength="40" /><br /><br />
		Subject:<br /><input name="subject" type="text" size="30" maxlength="40" /><br /><br />
		Message:<br /><textarea name="message" cols="50" rows="6"></textarea><br /><br />
		Please type in xtreme in the field below (to block spam)<br /><input name="antispam" type="text" size="30" maxlength="40" /><br /><br /></b>
		<input type="reset" value="Reset" />&nbsp;<input type="submit" value="Send" name="submit" />
		</form>






</span>
</small>
</div>
