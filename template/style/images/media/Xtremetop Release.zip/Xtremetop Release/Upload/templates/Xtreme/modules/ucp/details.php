<?php
/***************************************************************************
 *                                detail.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Subpage
{
	static function Build()
	{
		if(User::$isLoggedin != TRUE)
		{
			redirect('login');
		}

		$details = User::$details;

		if(isset($_POST['update']))
		{
			if(strlen($_POST['details']) <= 15000)
			{
				$id = User::$id;
				$details = $_POST['details'];
				$db_details = DB::safe($details);

				DB::query("UPDATE top_topsites SET details = '$db_details' WHERE id = '$id' LIMIT 1");
			}
		}

		Load::view('ucp/details', array('id' => User::$id, 'siteurl' => Config::item('siteurl'), 'details' => $details));
	}
}