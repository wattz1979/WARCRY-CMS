<?php
/***************************************************************************
 *                                Form.php
 *                            -------------------
 *   Project              : Flamework
 *   Begin                : June 2, 2010
 *   Copyright            : (C) 2009 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

if(!defined('FLAMEWORK')) die();

/*
 |-----------------------------------------------------------
 | Create Form
 |-----------------------------------------------------------
 |
 | Creates a form in a table.
 |
 | PARAMATERS:
 | - Action: The page the form leads to.
 | - Inputs: an array with the forms inputs.
 |
 |   EX: 	array
 |			(
 |			'username' => array(
 |				'label' => 'Username:',
 |				'kind' => 'input',
 |				'type' => 'text'),
 |
 |			'password' => array(
 |				'label' => 'Password:',
 |				'kind' => 'input',
 |				'type' => 'password'),
 |
 |			'login' => array(
 |				'kind' => 'input',
 |				'type' => 'submit',
 |				'value' => 'Login')
 |			);
 |
 | -Save: If true, the form will use the values from
 |		  the previous submitted form (if exists)
 */

function create_form($action = '?index', $inputs = array(), $save = FALSE)
{
	echo "<form method='post' action='$action'>\n";
	echo "<table>\n";
	
	if(is_array($inputs))
	{
		foreach($inputs as $name => $attributes)
		{
			$attributes = _parse_attributes($attributes, $name, $save);
			
			echo "	<tr>\n";
			echo "		<td><small>{$attributes['label']}</small></td>\n";
			echo '		<td>';
			switch($attributes['kind'])
			{
				case 'input':
					echo "<input type='{$attributes['type']}' name='$name' value='{$attributes['value']}'>";
					break;
			}
			
			echo "</td>\n";
			echo "	</tr>\n";
		}
	}
	
	echo "</table>\n";
	echo '</form>';
}

/*
 |-----------------------------------------------------------
 | Parse Attributes
 |-----------------------------------------------------------
 |
 | DO NOT USE!
 |
 | This is used by the create_form function to prepare the
 | inputs
 */

function _parse_attributes($attributes = array(), $name = '', $save = FALSE)
{
	switch($attributes['kind'])
	{
		case 'input': $required = array('label' => '', 'type' => 'text', 'value' => ''); break;
	}
	
	foreach($required as $k => $v)
	{		
		if(!isset($attributes[$k]))
		{
			$attributes[$k] = $v;
		}
	}

	if($save == TRUE)
	{
		if(isset($_POST[$name]))
		{
			$attributes['value'] = $_POST[$name];
		}
	}

	return $attributes;
}
?>