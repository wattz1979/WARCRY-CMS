<?php
/***************************************************************************
 *                                htmlcode.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Subpage
{
	static function Build()
	{
		if(User::$isLoggedin != TRUE)
		{
			redirect('login');
		}
		
		Load::view('ucp/htmlcode', array('id' => User::$id, 'siteurl' => Config::item('siteurl')));
	}
}