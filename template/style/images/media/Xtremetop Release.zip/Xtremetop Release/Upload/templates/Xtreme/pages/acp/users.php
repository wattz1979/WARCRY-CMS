	<h1><a href="#">TopsiteCMS</a></h1>
	<ul id="nav">
		<li><a href="?acp">Main Settings</a></li>
		<li class="active"><a href="#">Edit...</a>
			<ul>
				<li><a href="?acp=users">Users</a></li>
				<li><a href="?acp=navigation">Navigation</a></li>
				<li><a href="?acp=categories">Categories</a></li>
			</ul>
		</li>
		<li><a href="?acp=messages">View Messages</a></li>
		<li><a href="?index">View Site</a></li>
	</ul>
	
	<p class="user">Hello, <a href="?ucp"><?php echo User::$username; ?></a> | <a href="?logout">Logout</a></p>
</div>		<!-- #header ends -->

<?php if(isset($_GET['id']) && is_numeric($_GET['id'])): ?>
	<div class="block">

		<div class="block_head">
			<div class="bheadl"></div>
			<div class="bheadr"></div>

			<h2>Edit User `<?php echo $user['username']; ?>`</h2>
		</div>		<!-- .block_head ends -->


		<div class="block_content">
			<br />
			<b style="color:<?php echo $color; ?>;font-size:120%;"><?php echo $message; ?></b>
			<br /><br />
			<form method="post" action="?acp=users&id=<?php echo $user['id']; ?>">
				<p>
					<label>Username:</label><br />
					<input type="text" class="text medium" name="username" value="<?php echo $user['username']; ?>"/> 
					<span class="note"></span>
				</p>
				
				<p>
					<label>Email:</label><br />
					<input type="text" class="text medium" name="email" value="<?php echo $user['email']; ?>"/> 
					<span class="note"></span>
				</p>
				
				<p>
					<label>Months of VIP Left:</label><br />
					<input type="text" class="text small" name="isVIP" value="<?php echo $user['isVIP']; ?>"/> 
					<span class="note">* 0 = Not a VIP</span>
				</p>
				
				<p>
					<label>is an Admin:</label><br />
					<input type="text" class="text small" name="isAdmin" value="<?php echo $user['isAdmin']; ?>"/> 
					<span class="note">* 0 = NO, 1 = YES</span>
				</p>

				<br /><br />

				<p>
					<label>Site Title:</label><br />
					<input type="text" class="text medium" name="title" value="<?php echo $user['title']; ?>"/> 
				</p>
				
				<p><label>Category:</label> <br />

					<select name="category" class="styled">
						<?php foreach(categories() as $c): ?>
							<option value="<?php echo $c['id']; ?>" <?php if($c['id'] == $user['category']) echo 'selected=\'selected\''; ?>>
								<?php echo $c['name']; ?>
							</option>
						<?php endforeach; ?>
					</select></p>
				
				<p>
					<label>Site URL:</label><br />
					<input type="text" class="text medium" name="url" value="<?php echo $user['url']; ?>"/> 
				</p>
				
				<p>
					<label>Site Banner:</label><br />
					<input type="text" class="text medium" name="banner" value="<?php echo $user['banner']; ?>"/> 
				</p>
				
				<?php if(!empty($user['banner']) AND $user['banner'] != 'http://'): ?>
					<img src="<?php echo $user['banner']; ?>"><br /><br />
				<?php endif; ?>
				
				<p>
					<label>Main Description:</label><br />
					<textarea name="description"><?php echo $user['description']; ?></textarea>
				</p>
				
				<p>
					<label>In:</label><br />
					<input type="text" class="text medium" name="in" value="<?php echo $user['in']; ?>"/> 
				</p>
				
				<p>
					<label>Out:</label><br />
					<input type="text" class="text medium" name="out" value="<?php echo $user['out']; ?>"/> 
				</p>
				
				<p>
					<label>Details:</label><br />
					<textarea name="details"><?php echo $user['details']; ?></textarea>
				</p>
				
				<p>
					<input type="submit" name="edit" class="submit small" value="Save" />
				</p>
			</form>
		</div>		<!-- .block_content ends -->

		<div class="bendl"></div>
		<div class="bendr"></div>

	</div>
<?php else: ?>
<div class="block">

	<div class="block_head">
		<div class="bheadl"></div>
		<div class="bheadr"></div>
		
		<h2>Search for User</h2>
	</div>		<!-- .block_head ends -->

	<div class="block_content">
		<form method="get" action="?acp=users">
			<?php if($message == 'You can manage your users here.'): ?>
				<div class="message info"><p><?php echo $message; ?></p></div>
			<?php elseif($message == 'Settings saved successfully'): ?>
				<div class="message success"><p><?php echo $message; ?></p></div>
			<?php else: ?>
				<div class="message errormsg"><p><?php echo $message; ?></p></div>
			<?php endif; ?>

			<p>
				<input type="hidden" name="acp" value="users">
				<label>Search for User where:</label>
				<select class="styled" name="type">
					<option value="username" <?php if($type == 'username') echo 'selected="selected"'; ?>>Username</option>
					<option value="email" <?php if($type == 'email') echo 'selected="selected"'; ?>>Email</option>
					<option value="title" <?php if($type == 'title') echo 'selected="selected"'; ?>>Site's Title</option>
				</select></p>

			<p>
				<label>is:</label> <br />
				<input type="text" name="search" class="text medium error" value="<?php echo $search; ?>"/>
			</p>
			<br />

			<p>
				<input type="submit" class="submit small" value="Search" />
			</p>
		</form>	
	</div>		<!-- .block_content ends -->
	
	<div class="bendl"></div>
	<div class="bendr"></div>
		
</div>		<!-- .block ends -->

<?php if($search != ''): ?>
	<div class="block">

		<div class="block_head">
			<div class="bheadl"></div>
			<div class="bheadr"></div>

			<h2>Results</h2>
		</div>		<!-- .block_head ends -->


		<div class="block_content">
			<?php if(count($results) == 0): ?>
				<div class="message errormsg"><p>Could not find any results</p></div>
			<?php else: ?>
				<table cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<th>Username</th>
						<th>Email</th>
						<th>Site Title</th>
						<th>Site URL</th>
					</tr>

				<?php foreach($results as $r): ?>
					<tr>
						<td><a href="?acp=users&id=<?php echo $r['id']; ?>"><?php echo $r['username']; ?></a></td>
						<td><?php echo $r['email']; ?></td>
						<td><?php echo $r['title']; ?></td>
						<td><a href="<?php echo $r['url']; ?>"><?php echo $r['url']; ?></a>
					</tr>
				<?php endforeach; ?>

				</table>
			<?php endif; ?>
		</div>		<!-- .block_content ends -->

		<div class="bendl"></div>
		<div class="bendr"></div>

	</div>
<?php endif;?>
<?php endif; ?>	<!-- .block ends -->
		<!-- .leftcol ends -->