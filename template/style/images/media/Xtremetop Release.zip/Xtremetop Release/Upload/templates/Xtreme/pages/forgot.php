<div id="middlebtop">Password Recovery</div>
<div id="middlebtopa">
<small>
<span style="font-size: 12px; font-family:Verdana;">

<?php if($showform == TRUE): ?>
<form action="?forgot" method="post">
	Please enter the email you signed up with. <br /><br />
	<input type="text" name="email" size="40"> <br /><br />
	<input type="submit" name="submit" value="Send my password"> <br />
</form>
<?php else: ?>
<b style="color:<?php echo $color; ?>"><?php echo $message; ?></b>
<?php endif; ?>
</span>
</small>
</div>