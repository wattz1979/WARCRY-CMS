	<h1><a href="#">TopsiteCMS</a></h1>
	<ul id="nav">
		<li class="active"><a href="?acp">Main Settings</a></li>
		<li><a href="#">Edit...</a>
			<ul>
				<li><a href="?acp=users">Users</a></li>
				<li><a href="?acp=navigation">Navigation</a></li>
				<li><a href="?acp=categories">Categories</a></li>
			</ul>
		</li>
		<li><a href="?acp=messages">View Messages</a></li>
		<li><a href="?index">View Site</a></li>
	</ul>
	
	<p class="user">Hello, <a href="?ucp"><?php echo User::$username; ?></a> | <a href="?logout">Logout</a></p>
</div>		<!-- #header ends -->

<div class="block">

	<div class="block_head">
		<div class="bheadl"></div>
		<div class="bheadr"></div>
		
		<h2>Main Settings</h2>
	</div>		<!-- .block_head ends -->
	
	
	
	<div class="block_content">
		<form method="post" action="?acp">
			<?php if($message == 'You can edit your site\'s settings here.'): ?>
				<div class="message info"><p><?php echo $message; ?></p></div>
			<?php elseif($message == 'Settings saved successfully'): ?>
				<div class="message success"><p><?php echo $message; ?></p></div>
			<?php else: ?>
				<div class="message errormsg"><p><?php echo $message; ?></p></div>
			<?php endif; ?>
			
			<h2>Main Settings</h2>
			<p>
				<label>Site's Title:</label><br />
				<input type="text" name="title" class="text medium error" value="<?php echo Config::item('title'); ?>"/> 
			</p>
			
			<p>
				<label>Site URL:</label><br />
				<input type="text" name="siteurl" class="text medium error" value="<?php echo Config::item('siteurl'); ?>"/> 
			</p>
			
			<p>
				<label>Paypal Email:</label><br />
				<input type="text" name="paypal_email" class="text medium error" value="<?php echo Config::item('paypal_email'); ?>"/> 
			</p>

			<p>
				<label>Google Adsense ID:</label><br />
				<input type="text" name="adsense_id" class="text medium error" value="<?php echo Config::item('adsense_id'); ?>"/> 
			</p>

			<p>
				<label>Maximum Registrations per IP:</label><br />
				<input type="text" name="max_reg_ips" class="text medium error" value="<?php echo Config::item('max_reg_ips'); ?>"/> 
			</p>
			
			<p><label>Template:</label> <br />
			
				<select class="styled" name="template">
					<option value='<?php echo $default; ?>' selected='selected'><?php echo $default; ?></option>
					<?php foreach($templates as $template):?>
					<option value='<?php echo $template; ?>'><?php echo $template?></option>
					<?php endforeach; ?>
				</select></p>
			<br />
			
			<h2>Database Connection</h2>
			<p>
				<label>Hostname:</label><br />
				<input type="text" name="hostname" class="text medium error" value="<?php echo Config::item('hostname'); ?>"/> 
			</p>
			
			<p>
				<label>Username:</label><br />
				<input type="text" name="username" class="text medium error" value="<?php echo Config::item('username'); ?>"/> 
			</p>
			<p>
				<label>Password:</label><br />
				<input type="text" name="password" class="text medium error" value="<?php echo Config::item('password'); ?>"/> 
			</p>
			<p>
				<label>Database name:</label><br />
				<input type="text" name="database" class="text medium error" value="<?php echo Config::item('database'); ?>"/> 
			</p>
			<br />
			
			<h2>Brute Force Prevention</h2>
			<p>
				<label>Max Login Attempts:</label><br />
				<input type="text" name="max_attempts" class="text medium error" value="<?php echo Config::item('max_attempts'); ?>"/> 
			</p>
			<p>
				<label>Login Prevention Timer:</label><br />
				<input type="text" name="prevention_timer" class="text medium error" value="<?php echo Config::item('prevention_timer'); ?>"/> 
			</p>
			
			<p>
				<input type="submit" class="submit small" name='edit' value="Save" />
			</p>
		</form>
	
	<!--	<div class="message errormsg"><p>An error message goes here</p></div>
		
		<div class="message success"><p>A success message goes here</p></div>
		
		<div class="message info"><p>An informative message goes here</p></div>
		
		<div class="message warning"><p>A warning message goes here</p></div>
		
		
		<form action="" method="post">
			<p>
				<label>Small input label:</label><br />
				<input type="text" class="text small" /> 
				<span class="note">*A note</span>
			</p>
			
			<p>
				<label>Medium input label:</label><br />
				<input type="text" class="text medium error" /> 
				<span class="note error">Error!</span>
			</p>
			
			<p>
				<label>Big input label:</label><br />
				<input type="text" class="text big" />
			</p>
			
			<p>
				<label>Textarea label:</label><br />
				<textarea class="wysiwyg"></textarea>
			</p>
			
			<p>
				<label>Starting date:</label> 
				<input type="text" class="text date_picker" />
				&nbsp;&nbsp;
				<label>Ending date:</label> 
				<input type="text" class="text date_picker" />
			</p>
			
			
			<p><label>Select label:</label> <br />
			
				<select class="styled">
					<optgroup label="Group 1">
						<option>Option one</option>
						<option>Option two</option>
						<option>Option three</option>
					</optgroup>
					
					<optgroup label="Group 2">
						<option>Option one</option>
						<option>Option two</option>
						<option>Option three</option>
					</optgroup>
					
					<optgroup label="Group 3">
						<option>Option one</option>
						<option>Option two</option>
						<option>Option three</option>
					</optgroup>							
				</select></p>
			
									
			<p class="fileupload">
				<label>File input label:</label><br />
				<input type="file" id="fileupload" />
				<span id="uploadmsg">Max size 3Mb</span>
			</p>
															
			<p>
				<input type="checkbox" class="checkbox" checked="checked" id="cbdemo1" /> <label for="cbdemo1">Checkbox label</label> 
				<input type="checkbox" class="checkbox" id="cbdemo2" /> <label for="cbdemo2">Checkbox label</label>
			</p>
			
			<p><input type="radio" checked="checked" class="radio" /> <label>Radio button label</label></p>
									
			<hr />
			
			<p>
				<input type="submit" class="submit small" value="Submit" />
				<input type="submit" class="submit mid" value="Long submit" />
				<input type="submit" class="submit long" value="Even longer submit" />
			</p>
		</form>-->
		
		
	</div>		<!-- .block_content ends -->
	
	<div class="bendl"></div>
	<div class="bendr"></div>
		
</div>		<!-- .block ends -->
		<!-- .leftcol ends -->