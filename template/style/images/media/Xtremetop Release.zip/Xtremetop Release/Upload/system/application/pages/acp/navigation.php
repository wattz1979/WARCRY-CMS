<?php
/***************************************************************************
 *                                navigation.php
 *                            -------------------
 *   Project              : TopsiteCMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Subpage
{
	static $data = array(
		'message'		=> 'You can manage your users here.',
		'navigation'	=> array(),
		'edit_nav'		=> array());

	static function Build()
	{
		//Check for Admin
		if(User::$isAdmin == FALSE)
		{
			redirect();
		}

		//Delete navigation link
		if(isset($_GET['delete']) && is_numeric($_GET['delete']))
		{
			$id = $_GET['delete'];
			DB::query("DELETE FROM top_navigation WHERE id = '$id' LIMIT 1");
			DB::query("UPDATE top_navigation SET id = id - 1 WHERE id > $id");
			redirect('acp=navigation');
		}

		//Add navigation link
		if(isset($_POST['add']))
		{
			$new_id = $_POST['after'] + 1;
			$display = $_POST['display'];
			$link = $_POST['link'];

			//DB::query();
			mysql_query("UPDATE top_navigation SET `id` = `id` + 1 WHERE `id` >= $new_id ORDER BY id DESC") or die(mysql_error());
			DB::query("INSERT INTO top_navigation SET id = '$new_id', name = '$display', link = '$link'");
		}

		//Edit navigation links
		if(isset($_GET['id']) && is_numeric($_GET['id']))
		{
			DB::select('top_navigation', 'id = \''.$_GET['id'].'\'');

			if(DB::num_rows() > 0)
			{
				self::$data['edit_nav'] = DB::fetch_row();
			}
			
			else $_GET['id'] = 'text';

			if(isset($_POST['edit']))
			{
				self::edit_link();
			}
		}

		//Get the navigation
		DB::query("SELECT * FROM top_navigation ORDER BY id ASC");

		if(DB::num_rows() > 0)
		{
			self::$data['navigation'] = DB::fetch_array();
		}

		Load::view('navigation', self::$data, TRUE);
	}
	
	static function edit_link()
	{
		$id = $_GET['id'];
		$name = DB::safe($_POST['name']);
		$link = DB::safe($_POST['link']);

		if((self::$data['edit_nav']['id'] - 1) != $_POST['after'])
		{
			$new_id = $_POST['after'];
			$larger_id = $new_id;
			$smaller_id = $id;
			$order = 'ASC';
			$sign = '-';

			if((self::$data['edit_nav']['id'] - 1) > $_POST['after'])
			{
				$new_id++;
				$sign = '+';
				$order = 'DESC';
				$smaller_id = $new_id;
				$larger_id = $id;
			}

			$id = $new_id;
			DB::query("DELETE FROM top_navigation WHERE id = '$id' LIMIT 1");
			DB::query("UPDATE top_navigation SET `id` = `id` $sign 1 WHERE `id` >= '$smaller_id' AND `id` <= '$larger_id' ORDER BY id $order");
			DB::query("INSERT INTO top_navigation SET id = '$new_id', name = '$name', link = '$link'");
		}

		else
		{
			DB::query("UPDATE top_navigation SET name = '$name', link = '$link' WHERE id = '$id' LIMIT 1");
		}

		redirect('acp=navigation&id=' . $id);
		die();
	}


	static function message($message, $color = 'red')
	{
		self::$data['message'] = '<b style=\'color:'.$color.';\'>'.$message.'</b>';
	}
}