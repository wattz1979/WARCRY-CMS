<h1>ACP</h1>
<br>
<small><?php echo $message; ?></small>

<?php if($showselect == TRUE):?>
<br><br>
<form method='get' action=''>
	<input type='hidden' name='acp/pages'>
	<select name='page'>
		<?php if(isset($selected)):?>
		<option value='<?php echo $selected; ?>' selected='selected'><?php echo $selected; ?></option>
		<?php endif;?>
		<?php foreach($pages as $page):?>
		<option value='<?php echo $page; ?>'><?php echo $page; ?></option>
		<?php endforeach;?>
	</select>
	<br><br>
	<input type='submit' name='parse' value='Edit'>
</form>
<?php endif;?>

<?php if($showtextarea == TRUE):?>
<h2>Edit Page</h2>
<br>
<?php if(isset($editable) && $editable == FALSE):?>
<b style='color:red;'>This file is not editable and therefore cannot be save. Please make it writable.</b>
<br><br>
<?php endif;?>
<small>The path to the file is:</small><code><?php echo $page_path; ?></code>
<br><br>
<form method='post' action='?acp/pages&page=<?php echo $location; ?>'>
<textarea name='page' rows='20' cols='80'>
<?php echo file_get_contents($page_path);?>
</textarea>
<br><br>
<input type='submit' name='edit' value='Edit'>
</form>
<?php endif;?>