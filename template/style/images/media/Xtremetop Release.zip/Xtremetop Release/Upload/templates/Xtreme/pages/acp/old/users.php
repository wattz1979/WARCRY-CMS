<h1>ACP</h1>
<br>
<small><?php echo $message; ?></small>

<h2>Search for User</h2>

<form method='post' action=''>
	<small>Search:</small> 
	<input type='text' name='query' value='<?php echo $searched; ?>'>
	<select name='type'>
		<option value='username'>Username</option>
		<option value='ip'>IP</option>
		<option value='email'>Email</option>
		<option value='title'>Site Title</option>
	</select>
	<br>
	<input type='submit' name='search' value='Search'>
</form>

<?php if($showuser == TRUE):?>
<h2>User</h2>

<?php if(count($user) == 0):?>
<br>
<small>Could not find any results</small>

<?php else: ?>
<form method='post' action='?acp/users&username=<?php echo $user['username']; ?>'>
<table>
	<tr>
		<td><small>Username:</small></td>
		<td><input type='text' name='username' value='<?php echo $user['username']; ?>'>
	</tr>
	<tr>
		<td><small>Email:</small></td>
		<td><input type='text' name='email' value='<?php echo $user['email']; ?>'>
	</tr>
	<tr>
		<td><small>Password:</small></td>
		<td><input type='text' name='password' value=''>
	</tr>
	<tr>
		<td><small>Rank:</small></td>
		<td><select name='rank'>
				<option value='<?php echo $selected; ?>' selected='selected'><?php echo $selected; ?></option>
				<option value='<?php echo $unselected; ?>'><?php echo $unselected; ?></option>
			</select></td>
	</tr>
</table>
<input type='submit' name='edit' value='Edit'>
</form>
<?php endif; ?>

<?php endif; ?>
<br>