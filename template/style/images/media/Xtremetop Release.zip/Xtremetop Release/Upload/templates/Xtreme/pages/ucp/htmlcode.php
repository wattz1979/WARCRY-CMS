<div id="middlebtop">HTML Code</div>
<div id="middlebtopa">
<small>
<span style="font-size: 12px; font-family:Verdana;">


<ul id="thicktabs">
	<li><a href="?ucp" id="leftmostitem">Main edit</a></li>
	<li><a href="?edit=details">Website details</a></li>
	<li><a href="?edit=screenshots">Upload screenshots</a></li>
	<li><a href="?edit=membership">Gold membership</a></li>
	<li><a href="?edit=htmlcode">Get HTML code</a></li>
	<span style="float:right; font-size: 13px; color: red;"><li><a href="?logout">Logout!</a></li></span>
</ul>
<br style="clear: left" />
<br />

		<div id="boxy">
		<ul>	
		<li>Manipulating the code below is against our rules, doing so might cause problems to the functionalities.</li><br />
		</ul>
		</div>
<br /><br />

<b>HTML Code:</b><br />
<textarea rows="10" name="code" cols="86">
<!-- Begin <?php echo Config::item('title'); ?> code -->
<a href="<?php echo Config::item('siteurl'); ?>?in=<?php echo $id; ?>">
<img src="<?php echo Config::item('siteurl'); ?>vote.jpg" border="0" alt="private server"></a>
<!-- End <?php echo Config::item('title'); ?> code -->
</textarea><br /><br /><br />





<b>This is how the code will look on your website:</b><br /><br />

<!-- Begin <?php echo Config::item('title'); ?> code -->
<a href="<?php echo Config::item('siteurl'); ?>?in=<?php echo $id; ?>">
<img src="<?php echo Config::item('siteurl'); ?>vote.jpg" border="0" alt="private server"></a>
<!-- End <?php echo Config::item('title'); ?> code -->

<br />
</span>
</small>
</div>