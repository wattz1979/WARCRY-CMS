	<h1><a href="#">TopsiteCMS</a></h1>
	<ul id="nav">
		<li><a href="?acp">Main Settings</a></li>
		<li class="active"><a href="#">Edit...</a>
			<ul>
				<li><a href="?acp=users">Users</a></li>
				<li><a href="?acp=navigation">Navigation</a></li>
				<li><a href="?acp=categories">Categories</a></li>
			</ul>
		</li>
		<li><a href="?acp=messages">View Messages</a></li>
		<li><a href="?index">View Site</a></li>
	</ul>
	
	<p class="user">Hello, <a href="?ucp"><?php echo User::$username; ?></a> | <a href="?logout">Logout</a></p>
</div>		<!-- #header ends -->

<?php if(isset($_GET['id']) && is_numeric($_GET['id'])): ?>
	<div class="block">

		<div class="block_head">
			<div class="bheadl"></div>
			<div class="bheadr"></div>

			<h2>Edit Navigation</h2>
		</div>		<!-- .block_head ends -->


		<div class="block_content">
			<form method="post" action="?acp=navigation&id=<?php echo $_GET['id']; ?>">
				<p>
					<label>Display:</label><br />
					<input type="text" name="name" class="text medium error" value="<?php echo $edit_nav['name']; ?>"/>
				</p>

				<p>
					<label>Link:</label><br />
					<input type="text" name="link" class="text medium error" value="<?php echo $edit_nav['link']; ?>"/>
				</p>

				<p><label>After Link:</label> <br />
					<?php $i = 0; ?>
					<?php $count = count($navigation); ?>
					<select name="after" class="styled">
						<option value="0">None</option>
						<?php foreach($navigation as $n): ?>
							<?php $i++; ?>
							<?php if($i != $edit_nav['id']): ?>
							<option value="<?php echo $n['id']; ?>" <?php if($edit_nav['id'] - 1 == $i) echo 'selected="selected"'; ?>><?php echo $n['name']; ?></option>
							<?php endif; ?>
						<?php endforeach; ?>					
					</select></p>
				<p>
					<input type="submit" name="edit" class="submit small" value="Save" />
				</p>
			</form>
		</div>		<!-- .block_content ends -->

		<div class="bendl"></div>
		<div class="bendr"></div>

	</div>
<?php else: ?>
<div class="block">

	<div class="block_head">
		<div class="bheadl"></div>
		<div class="bheadr"></div>
		
		<h2>Add Navigation</h2>
	</div>		<!-- .block_head ends -->

	<div class="block_content">
		<form method="post" action="?acp=navigation">

			<p>
				<label>Display:</label><br />
				<input type="text" name="display" class="text medium error" value=""/>
			</p>

			<p>
				<label>Link:</label><br />
				<input type="text" name="link" class="text medium error" value=""/>
			</p>

			<p><label>After Link:</label> <br />
				<?php $i = 0; ?>
				<?php $count = count($navigation); ?>
				<select name="after" class="styled">
					<?php foreach($navigation as $n): ?>
						<?php $i++; ?>
						<option value="<?php echo $n['id']; ?>" <?php if($count == $i) echo 'selected="selected"'; ?>><?php echo $n['name']; ?></option>
					<?php endforeach; ?>					
				</select></p>

			<p>
				<input type="submit" class="submit small" name="add" value="Add" />
			</p>
		</form>
	
	<!--	<div class="message errormsg"><p>An error message goes here</p></div>
		
		<div class="message success"><p>A success message goes here</p></div>
		
		<div class="message info"><p>An informative message goes here</p></div>
		
		<div class="message warning"><p>A warning message goes here</p></div>
		
		
		<form action="" method="post">
			<p>
				<label>Small input label:</label><br />
				<input type="text" class="text small" /> 
				<span class="note">*A note</span>
			</p>
			
			<p>
				<label>Medium input label:</label><br />
				<input type="text" class="text medium error" /> 
				<span class="note error">Error!</span>
			</p>
			
			<p>
				<label>Big input label:</label><br />
				<input type="text" class="text big" />
			</p>
			
			<p>
				<label>Textarea label:</label><br />
				<textarea class="wysiwyg"></textarea>
			</p>
			
			<p>
				<label>Starting date:</label> 
				<input type="text" class="text date_picker" />
				&nbsp;&nbsp;
				<label>Ending date:</label> 
				<input type="text" class="text date_picker" />
			</p>
			
			
			<p><label>Select label:</label> <br />
			
				<select class="styled">
					<optgroup label="Group 1">
						<option>Option one</option>
						<option>Option two</option>
						<option>Option three</option>
					</optgroup>
					
					<optgroup label="Group 2">
						<option>Option one</option>
						<option>Option two</option>
						<option>Option three</option>
					</optgroup>
					
					<optgroup label="Group 3">
						<option>Option one</option>
						<option>Option two</option>
						<option>Option three</option>
					</optgroup>							
				</select></p>
			
									
			<p class="fileupload">
				<label>File input label:</label><br />
				<input type="file" id="fileupload" />
				<span id="uploadmsg">Max size 3Mb</span>
			</p>
															
			<p>
				<input type="checkbox" class="checkbox" checked="checked" id="cbdemo1" /> <label for="cbdemo1">Checkbox label</label> 
				<input type="checkbox" class="checkbox" id="cbdemo2" /> <label for="cbdemo2">Checkbox label</label>
			</p>
			
			<p><input type="radio" checked="checked" class="radio" /> <label>Radio button label</label></p>
									
			<hr />
			
			<p>
				<input type="submit" class="submit small" value="Submit" />
				<input type="submit" class="submit mid" value="Long submit" />
				<input type="submit" class="submit long" value="Even longer submit" />
			</p>
		</form>-->
		
		
	</div>		<!-- .block_content ends -->
	
	<div class="bendl"></div>
	<div class="bendr"></div>
		
</div>
<?php endif; ?>		<!-- .block ends -->

<div class="block">

	<div class="block_head">
		<div class="bheadl"></div>
		<div class="bheadr"></div>

		<h2>Edit Navigation</h2>
	</div>		<!-- .block_head ends -->


	<div class="block_content">
		<?php if(count($navigation) == 0): ?>
			<div class="message errormsg"><p>Could not find any results</p></div>
		<?php else: ?>
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<th>Display</th>
					<th>Link</th>
					<th>Action</th>
				</tr>

			<?php foreach($navigation as $n): ?>
				<tr>
					<td><?php echo $n['name']; ?></td>
					<td><?php echo $n['link']; ?></td>
					<td><a href="?acp=navigation&id=<?php echo $n['id']; ?>">Edit</a> | <a href="?acp=navigation&delete=<?php echo $n['id']; ?>">Delete</a>
				</tr>
				<?php //dump($r); ?>
			<?php endforeach; ?>

			</table>
		<?php endif; ?>
	</div>		<!-- .block_content ends -->

	<div class="bendl"></div>
	<div class="bendr"></div>

</div><!-- .block ends -->
		<!-- .leftcol ends -->