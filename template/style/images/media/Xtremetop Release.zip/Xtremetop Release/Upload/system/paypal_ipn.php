<?php
/***************************************************************************
 *                                paypal_ipn.php
 *                            -------------------
 *   Project              : TopsiteCMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robet Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

/*******************************************************
 *				Paypal Payment Confirmation
 *******************************************************/

// read the post from PayPal system and add 'cmd'
$req = 'cmd=_notify-validate';

foreach ($_POST as $key => $value)
{
	$value = urlencode(stripslashes($value));
	$req .= "&$key=$value";
}

// post back to PayPal system to validate
$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
$fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);

// assign posted variables to local variables
$item_name = $_POST['item_name'];
$item_number = $_POST['item_number'];
$payment_status = $_POST['payment_status'];
$payment_amount = $_POST['mc_gross'];
$payment_currency = $_POST['mc_currency'];
$txn_id = $_POST['txn_id'];
$receiver_email = $_POST['receiver_email'];
$payer_email = $_POST['payer_email'];

//Connect to the server
define('IN_TOPSITE', TRUE);
include 'config/main.conf';

if(mysql_connect($conf['hostname'], $conf['username'], $conf['password']))
{
	if(!mysql_select_db($conf['database']))
	{
		write_error('Could not select database');
	}
}

else write_error('Could not connect to server');

if(!$fp)
{
	log_error('HTML ERROR');
}

else
{
	fputs ($fp, $header . $req);

	while (!feof($fp))
	{
		$res = fgets ($fp, 1024);
		if(strcmp ($res, "VERIFIED") == 0)
		{
			//Check email
			if($conf['paypal_email'] == $_POST['receiver_email'])
			{
				//Is the payment completed?
				if($payment_status == 'Completed')
				{
					//Did they pay more than $15?
					if($payment_amount >= 15 && $payment_currency == 'USD')
					{
						//Get the amount of months paid for
						$months = ceil($payment_amount / 15);
						
						if(mysql_connect($conf['hostname'], $conf['username'], $conf['password']))
						{
							if(mysql_select_db($conf['database']))
							{
								$q = mysql_query("SELECT txn_id FROM top_payments WHERE txn_id = '$txn_id' LIMIT 1");
								
								if(mysql_num_rows($q) == 0)
								{
									$q = mysql_query("SELECT username FROM top_payment_requests WHERE pp_email = '$payer_email' LIMIT 1");
									
									if(mysql_num_rows($q) > 0)
									{
										$username = mysql_fetch_assoc($q);
										$username = $username['username'];
										$serial = serialize($_POST);
										
										//Record Payment
										$query  = "INSERT INTO top_payments SET txn_id = '$txn_id', success = '1', ";
										$query .= "email = '$payer_email', data = '$serial', error_message = 'Successful Payment'";
										mysql_query($query);

										//Register VIP
										mysql_query("UPDATE top_topsites SET isVIP = '$months' WHERE username = '$username' LIMIT 1");
									}
									
									else log_error('Could not find topsite using email address `'.$payer_email.'`');
								}
								
								else log_error('Duplicate payment');
							}
							
							else log_error('Could not select database');
						}
						
						else log_error('Could not connect to server...');
					}
					
					else log_error('Fraud attempt: Invalid currency/amount');
				}
				
				else log_error('Fraud attempt: Uncompleted payment');
			}
			
			else log_error('Fraud attempt: wrong email');
		}

		elseif(strcmp ($res, "INVALID") == 0)
		{
			log_error('manual investigation');
		}
	}

	fclose ($fp);
}

function write_error($content)
{
	$filename = 'paypal.txt';

	if (is_writable($filename))
	{
	    $handle = fopen($filename, 'w+');
		fwrite($handle, $content);
	    fclose($handle);
	}
}


function log_error($content)
{
	$txn_id = $_POST['txn_id'];
	$serial = serialize($_POST);
	mysql_query("INSERT INTO top_payments SET txn_id = '$txn_id', success = '0', data = '$serial', error_message = '$content'");
}