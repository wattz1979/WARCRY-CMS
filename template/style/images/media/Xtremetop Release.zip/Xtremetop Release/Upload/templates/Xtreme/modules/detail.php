<?php
/***************************************************************************
 *                                detail.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Page
{
	static function Build()
	{
		$id = $_GET['detail'];
		if(empty($id) ||  !is_numeric($id))
		{
			redirect();
		}

		DB::select('top_topsites', 'id = \''.$id.'\'', '1');
		
		if(DB::num_rows() > 0)
		{
			$data = array();
			$data = DB::fetch_row();

			DB::select('top_screenshots', 'site_id = \''.$id.'\'');
			$data['screenshot_count'] = DB::num_rows();
			$data['screenshots'] = DB::fetch_array();

			Load::view('detail', $data);
		}
		
		else redirect();
	}
}