<?php if(User::$isAdmin == TRUE):?>
	<?php if($isACP == FALSE):?>
		<center><a href='?acp'>Admin Control Panel</a></center>
	<?php else:?>
		<center><a href='?index'>View Site</a></center>
	<?php endif; ?>
<?php endif; ?>
</body>
</html>