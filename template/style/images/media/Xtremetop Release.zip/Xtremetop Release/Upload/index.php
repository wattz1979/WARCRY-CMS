<?php
/***************************************************************************
 *                                index.php
 *                            -------------------
 *   Project              : TopsiteCMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robet Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

/*******************************************************
 *				BEGINNING OF CONFIGURATION
 *******************************************************/

/*
|--------------------------------------------------------
| DEBUG LEVEL
|--------------------------------------------------------
|
| Define the debugging level. Please note that a debug level
| higher than 0 will cause slower load times.
*/

define('DEBUG', TRUE);

/*
|---------------------------------------------------------------
| INDEX CHECKER
|---------------------------------------------------------------
|
| Allows all files that should be loaded from the index
| file to check that they are not directly accessed
|
*/

define('IN_TOPSITE', TRUE);

/*
|---------------------------------------------------------------
| TOPSITE CMS VERSION
|---------------------------------------------------------------
|
| The version of the TopsiteCMS.
|
*/

define('VERSION',   '1.0.0');

/*******************************************************
 *				END OF CONFIGURATION
 *******************************************************/


include 'system/core/Topsite.php';