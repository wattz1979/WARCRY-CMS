<?php
/***************************************************************************
 *                                out.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Page
{
	static function Build()
	{
		if(empty($_GET['out']) || !is_numeric($_GET['out']))
		{
			redirect();
		}

		$id = $_GET['out'];
		DB::query("SELECT url FROM top_topsites WHERE id = '$id'");

		if(DB::num_rows() > 0)
		{
			$site = DB::fetch_row();
			$ip = (getenv('HTTP_X_FORWARDED_FOR')) ? getenv('HTTP_X_FORWARDED_FOR') : getenv('REMOTE_ADDR');

			if(self::already_voted($id, $ip) == FALSE)
			{
				$time = time();
				DB::query("UPDATE top_topsites SET `out` = `out` + 1, `outtotal` = `outtotal` + 1 WHERE id = '$id' LIMIT 1");
				DB::query("INSERT INTO top_actions SET siteid = '$id', ip = '$ip', action = '1', `timestamp` = '$time'");
			}

			header('location: '. $site['url']);
		}

		else redirect();
	}

	static function already_voted($id, $ip)
	{
		DB::select('top_actions', "ip = '$ip' AND siteid = '$id' AND action = '1' ORDER BY `timestamp` DESC", '1');

		if(DB::num_rows() > 0)
		{
			$info = DB::fetch_row();

			if($info['timestamp'] >= time() - 60*60*12)
			{
				return TRUE;
			}
		}

		return FALSE;
	}
}