<?php
/***************************************************************************
 *                                register.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Page
{
	static function Build()
	{
		if(User::$isLoggedin == TRUE)
		{
			redirect('ucp');
			return;
		}

		$data = array
		(
			'message'		=> 'Please register using your desired information',
			'username'		=> '',
			'password'		=> '',
			'confirm'		=> '',
			'email'			=> '',
			'title'			=> '',
			'url'			=> 'http://',
			'category'		=> '1',
			'banner'		=> 'http://',
			'description'	=> ''
 		);

		$data['message']  = 'Please register to using your desired information.';
		
		if(isset($_POST['register']))
		{
			$error = FALSE;
			$query = 'INSERT INTO top_topsites SET ';
			$i = 0;

			foreach($_POST as $k => $v)
			{
				$v = DB::safe($v);
				$data[$k] = $v;
				
				if($error == FALSE)
				{
					if((is_numeric($v) && $v == 0) || empty($v))
					{
						if($k != 'banner')
						{
							$data['message'] = self::msg('The ' . ucfirst($k) . ' field cannot be empty');
							$error = TRUE;
						}
					}

					if($k == 'confirm')
					{
						if($data['password'] == $v)
						{
							$v = md5($data['username'] . $v);
						}
			
						else
						{
							$data['message'] = self::msg('The passwords must match!');
							$error = TRUE;
						}
					}
					
					if($k == 'title')
					{
						if(strlen($v) > 40)
						{
							$data['message'] = self::msg('The site\'s title cannot be over 40 characters long');
						}
					}

					if($k == 'description')
					{
						if(strlen($v) > 300)
						{
							$data['message'] = self::msg('The site\'s description cannot be over 300 characters long');
						}
					}

					$i++;
					if($k != 'password' && $k != 'register')
					{
						if($k == 'confirm') $k = 'password';

						$query .= $k . ' = \'' . $v . '\'';
						$query .= ($i != count($_POST) - 1) ? ', ' : ', details = \' \' ';
					}
				}
			}

			if($error != TRUE)
			{
					$ip = (getenv('HTTP_X_FORWARDED_FOR')) ? getenv('HTTP_X_FORWARDED_FOR') : getenv('REMOTE_ADDR');
					DB::query("SELECT id FROM top_topsites WHERE ip = '$ip'");

					if(DB::num_rows() < Config::item('max_reg_ips'))
					{
						DB::query("SELECT id FROM top_topsites WHERE url = '".$data['url']."' LIMIT 1");

						if(DB::num_rows() == 0)
						{
							DB::query("SELECT id FROM top_topsites WHERE username = '".$data['username']."' LIMIT 1");

							if(DB::num_rows() == 0)
							{
								DB::query($query);
								User::login($data['username'], $data['password']);
								redirect('ucp');
							}

							else $data['message'] = self::msg('Username `'.$data['username'].'` is taken');
						}

						else $data['message'] = self::msg('URL `'.$data['url'].'` is taken');
					}
					
					else $data['message'] = self::msg('Only up to ' . Config::item('max_reg_ips') . ' sites are allowed per IP');
				}
			}

		Load::view('register', $data);
	}

	static function categories()
	{
		DB::select('top_categories');
		return (DB::num_rows() > 0) ? DB::fetch_array() : array();
	}

	static function msg($message = '', $color = 'red')
	{
		return '<b style=\'color:' . $color . ';\'>' . $message . '</b>';
	}
}