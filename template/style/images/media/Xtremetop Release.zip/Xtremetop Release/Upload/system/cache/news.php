a:1:{i:0;a:6:{s:2:"id";i:0;s:5:"title";s:20:"Welcome to Your Site";s:4:"body";s:93:"Welcome to your site! You can now manage your site from the ACP.

Enjoy,
The UnityCMS Team";s:6:"author";s:8:"maverfax";s:9:"timestamp";i:1276985509;s:8:"comments";a:0:{}}}