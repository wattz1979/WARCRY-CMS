<?php
/***************************************************************************
 *                                ucp.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

class Page
{
	static $message = 'You can edit your settings here.';
	
	static function Build($id)
	{
		if(User::$isLoggedin == FALSE)
		{
			redirect('login');
		}

		if(isset($_POST['edit']))
		{
			self::edit_user($id);
		}
		
		if(User::$isAdmin == TRUE && $id != FALSE)
		{
			if(is_numeric($id))
			{
				DB::select('top_topsites', 'id = \''.$id.'\'', '1');

				if(DB::num_rows() > 0)
				{
					$user = DB::fetch_row();
					$data = array
					(
						'id'			=> $id,
						'username'		=> $user['username'],
						'email'			=> $user['email'],
						'title'			=> $user['title'],
						'url'			=> $user['url'],
						'category'		=> $user['category'],
						'description'	=> $user['description'],
						'banner'		=> $user['banner'],
					);
				}

				else redirect();
			}

			else redirect();
		}

		else
		{
			$data = array
			(
				'id'			=> User::$id,
				'username'		=> User::$username,
				'email'			=> User::$email,
				'title'			=> User::$title,
				'url'			=> User::$url,
				'category'		=> User::$category,
				'description'	=> User::$description,
				'banner'		=> User::$banner,
			);
		}

		$data['message'] = self::$message;
		Load::view('ucp', $data);
	}
	
	static function edit_user($id)
	{
		$user = array();
		$userid = User::$id;

		if(User::$isAdmin == TRUE && $id != 'none')
		{
			if(is_numeric($id))
			{
				$userid = $id;
			}
		}

		foreach($_POST as $k => $v)
		{
			if(isset(User::$$k))
			{
				if($k == 'title')
				{
					if(strlen($v) > 40)
					{
						self::message('Your site\'s title must be shorter than 40 characters');
						return;
					}
				}

				elseif($k == 'description')
				{
					if(strlen($v) > 300)
					{
						self::message('Your site\'s description must be shorter than 300 characters');
					}
				}

				$v = DB::safe($v);
				$user[$k] = $v;
				User::$$k = stripslashes($v);
			}
		}

		self::message('Successfully saved settings', 'green');

		if(!empty($_POST['previous']))
		{
			if(md5(User::$username . $_POST['previous']) == User::$password)
			{
				if(strlen($_POST['new']) > 2)
				{
					if($_POST['new'] == $_POST['confirm'])
					{
						$encrypted = md5(User::$username . $_POST['new']);
						$user['password'] = $encrypted;
						User::$password   = $encrypted;
					}

					else self::message('The passwords must match');
				}

				else self::message('The new password must be at least 3 characters');
			}

			else self::message('Invalid previous password');
		}

		User::save($userid, $user);
	}

	static function categories()
	{
		DB::select('top_categories');
		return (DB::num_rows() > 0) ? DB::fetch_array() : array();
	}

	static function message($message = '', $color = 'red')
	{
		self::$message = '<b style=\'color:'.$color.';\'>' . $message . '</b>';
	}
}