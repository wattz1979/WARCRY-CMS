<?php
/***************************************************************************
 *                                Cache.php
 *                            -------------------
 *   Project              : Flamework
 *   Begin                : June 2, 2010
 *   Copyright            : (C) 2009 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

if(!defined('FLAMEWORK')) die();

class Cache
{
	static $expiry   = 3600;
	static $cache    = NULL;
	static $content  = NULL;
	
	static function init($cache, $expiry = 60)
	{
		self::$expiry  = $expiry * 60;
		self::$cache   = 'system/cache/' . $cache . '.php';
		self::$content = NULL;
	}
	
	static function isValid()
	{
		if(!is_null(self::$cache))
		{
			if(filemtime(self::$cache) > (time() - self::$expiry))
			{
				return true;
			}
		}

		return false;
	}
	
	static function get()
	{
		if(!is_null(self::$cache) && file_exists(self::$cache))
		{
			if(is_null(self::$content))
			{
				$fh = fopen(self::$cache, 'r');
				self::$content = fread($fh, filesize(self::$cache));
				fclose($fh);
			}

			return self::$content;
		}
		
		return false;
	}
	
	static function set($content = '')
	{
		if(!is_null(self::$cache))
		{
			if(is_array($content))
			{
				$content = serialize($content);
			}

			$fh = fopen(self::$cache, 'w+');
			fwrite($fh, $content);
			fclose($fh);
		}
	}
	
	static function output($time = 10)
	{
		Base::$path = 'system/cache/' . Base::$page . '.php';
		Base::$cache = $time * 60;
	}
}
?>