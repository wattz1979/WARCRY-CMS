<h1>UCP</h1>
<br>
<small><?php echo $message; ?></small>

<h2>Main Settings</h2>
<form method='post' action='?ucp=<?php echo $userid; ?>'>
<table>
	<tr>
		<td><small>Email:</small></td>
		<td><input type='text' name='email' value='<?php echo User::$email; ?>'></td>
	</tr>
</table>

<h2>Change Password</h2>
<small>Leaving this blank will not change your password.</small>
<br><br>

<table>
	<tr>
		<td><small>Previous:</small></td>
		<td><input type='password' name='previous' value=''></td>
	</tr>
	<tr>
		<td><small>News:</small></td>
		<td><input type='password' name='new' value=''></td>
	</tr>
	<tr>
		<td><small>Confirm:</small></td>
		<td><input type='password' name='confirm' value=''></td>
	</tr>
</table>

<h2>Site Information</h2>
<small>Please type in the information about your site here.</small>
<br><br>

<table>
	<tr>
		<td><small>Title:</small></td>
		<td><input type='text' name='title' value='<?php echo $title; ?>'></td>
	</tr>
	<tr>
		<td><small>Category:</small></td>
		<td><select name='category'>
			<?php foreach(Page::categories() as $cat):?>
			<option value='<?php echo $cat['id']; ?>' <?php if($cat['id'] == $category) echo 'selected=\'selected\''; ?>><?php echo $cat['name']; ?></option>
			<?php endforeach; ?>
		</select></td>
	</tr>
	<tr>
		<td><small>URL:</small></td>
		<td><input type='text' name='url' value='<?php echo $url; ?>'></td>
	</tr>	
	<tr>
		<td><small>Banner:</small></td>
		<td><input type='text' name='banner' value='<?php echo $banner; ?>'></td>
	</tr>
	<tr>
		<td><small>Description:</small></td>
		<td><textarea name='description' rows='10' cols='50'><?php echo $description; ?></textarea></td>
	</tr>
</table>


<input type='submit' name='edit' value='Save'>
</form>