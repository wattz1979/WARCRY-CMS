<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Processing...</title>
</head>

<body onload="document.paypal_form.submit();">
<h2>Processing Transaction...</h2>
<p><strong>Please wait...</strong></p>
<form method="post" name="paypal_form" action="https://www.paypal.com/cgi-bin/webscr">

    <input type="hidden" name="business" value="<?php echo $email; ?>" />
    <input type="hidden" name="cmd" value="_xclick" />
    <!-- the next three need to be created -->
    <input type="hidden" name="return" value="<?php echo $return_url; ?>" />
    <input type="hidden" name="cancel_return" value="<?php echo $return_url; ?>" />
    <input type="hidden" name="notify_url" value="<?php echo $ipn_url; ?>" />
    <input type="hidden" name="rm" value="2" />
    <input type="hidden" name="currency_code" value="USD" />
    
    <!-- Product Information -->
    <input type="hidden" name="item_name" value="VIP Monthly Payment" />
    <input type="hidden" name="amount" value="<?php echo $payment; ?>" />
    
    <!-- Customer Information -->

<noscript><p>Your browser doesn't support Javscript, click the button below to process the transaction.</p>
<input type="submit" name="Submit" value="Process Payment" />
</noscript>
</form>
</body>
</html>
