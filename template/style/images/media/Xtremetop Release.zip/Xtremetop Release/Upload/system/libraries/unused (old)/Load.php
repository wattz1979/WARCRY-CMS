<?php
/***************************************************************************
 *                                Config.php
 *                            -------------------
 *   Project              : Flamework
 *   Begin                : June 2, 2010
 *   Copyright            : (C) 2009 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

if(!defined('FLAMEWORK')) die();

class Load
{
	static $classes  = array();
	static $helpers  = array();
	static $template = FALSE;
	
	static function library($name, $data = array())
	{
		$name	  = capitalize($name);
		$path 	  = LIB . $name . '.php';
		
		if(file_exists($path))
		{
			if(!isset(self::$classes[$name]))
			{
				self::$classes[$name] = TRUE;
				include $path;
				
				if(is_callable(array($name, 'Build')))
				{
					call_user_func(array($name, 'Build'));
				}
			}
		}	
	}
	
	static function view($name, $data = array(), $isACP = FALSE)
	{
		if(file_exists(self::$template . 'pages/' . $name . '.php'))
		{
			$navigation = Base::$navigation;
			$title 		= Config::item('title');
			
			foreach($data as $k => $v)
			{
				$$k = $v;
			}

			include self::$template . 'global/header.php';
			include self::$template . 'pages/' . $name . '.php';
			include self::$template . 'global/footer.php';
		}
	}
	
	static function helper($name)
	{
		$name 	= capitalize($name);
		$path 	= 'system/helpers/' . $name . '.php';
		
		if(!isset(self::$helpers[$name]))
		{
			self::$helpers[$name] = TRUE;

			if(file_exists($path))
			{
				include $path;
			}
		}
	}
	
	static function config($name)
	{
		Config::load($name);
	}
	
	static function language($filename, $language = 'english')
	{
		if(!isset(self::$classes['Language']))
		{
			self::library('language');
		}
		
		Language::load($filename, $language);
	}
}