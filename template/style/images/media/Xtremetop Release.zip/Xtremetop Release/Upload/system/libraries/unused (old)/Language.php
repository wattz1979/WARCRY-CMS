<?php
/***************************************************************************
 *                                Language.php
 *                            -------------------
 *   Project              : Flamework
 *   Begin                : June 10, 2010
 *   Copyright            : (C) 2009 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

if(!defined('FLAMEWORK')) die();

class Language
{
	static $lang     = array();
	static $files	 = array();

	static function load($filename, $language = 'english')
	{
		$return   = array();
		$name	  = strtolower($filename);
		$filename = capitalize($filename);
		$language = capitalize($language);
		

		$path = APP . 'language/' . $language . '/' . $filename . '.php';

		if(file_exists($path))
		{
			include $path;

			if(isset($lang))
			{
				$return = $lang;
				self::$lang[$language] = array_merge($lang, self::$Loaded[$language]);
			}

			if(isset($$name))
			{
				$return = array_merge($return, $$name);
				self::$files[$language][$filename] = $$name;
			}
		}
		
		return $return;
	}

	static function item($name, $filename = '', $language = 'english')
	{
		$filename = capitalize($filename);
		$language = capitalize($language);
		
		if($filename != '')
		{
			if(isset(self::$files[$language][$filename][$name]))
			{
				return self::$files[$language][$filename][$name];
			}
		}
		
		else
		{
			if(isset(self::$lang[$language][$name]))
			{
				return self::$lang[$language][$name];
			}
		}
	}
}
?>