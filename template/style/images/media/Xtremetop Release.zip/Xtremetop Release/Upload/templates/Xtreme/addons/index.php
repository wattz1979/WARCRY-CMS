<?php
/***************************************************************************
 *                                index.php
 *                            -------------------
 *   Project              : Topsite CMS
 *   Begin                : June 11, 2010
 *   Copyright            : (C) 2010 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

function can_edit($site)
{
	return ((User::$isLoggedin == TRUE && User::$id == $site['id']) || User::$isAdmin == TRUE) ? TRUE : FALSE;
}

function show_banner($site)
{
	return ($site['isVIP'] == TRUE && !empty($site['banner']) && $site['banner'] != 'http://') ? TRUE : FALSE;
}