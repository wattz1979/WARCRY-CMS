<?php
/***************************************************************************
 *                                Database.php
 *                            -------------------
 *   Project              : Flamework
 *   Begin                : June 2, 2010
 *   Copyright            : (C) 2009 Robert Herman ( maverfax@gmail.com )
 *
 ***************************************************************************/

if(!defined('IN_TOPSITE')) die();

class DB
{
	static $connection  = NULL;
	static $connections = array();
	static $querycount  = 0;
	static $queries		= array();
	
	function Build()
	{
		$c = Config::load('main');
		self::connect($c['hostname'], $c['username'], $c['password'], $c['database']);
	}

	/*
	|--------------------------------------------------------------|
	|							CONNECT							   |
	|--------------------------------------------------------------|
	*/
	
	function connect($hostname, $username, $password, $database)
	{
		$conid = mysql_connect($hostname, $username, $password, TRUE);

		if($conid == FALSE)
		{
			if(DEBUG == TRUE)
			{
				show_error("MySQL Connection using `$hostname`, `$username`, `$password` was refused");
			}
			
			return;
		}
		
		else
		{
			$dbid = mysql_select_db($database, $conid);
			
			if($dbid == FALSE)
			{
				if(DEBUG == TRUE)
				{
					show_error("MySQL could not connect to database `$database`");
				}

				return;
			}
			
			else
			{
				self::$connections[] = $conid;
				self::$connection    = $conid;
			}
		}
	}
	
	static function switchConnection($id = 0)
	{
		if(isset(self::$connections[$id]))
		{
			self::$connection = self::$connections[$id];
		}
		
		else
		{
			show_error('Connection id `'.$id.'` does not exist');
		}
	}
	
	/*
	|--------------------------------------------------------------|
	|				SAFE (cleans query string)					   |
	|--------------------------------------------------------------|
	*/

	static function safe($s = '')
	{
		//TODO: finish this... not exactly perfect
		return mysql_real_escape_string($s);
	}

	/*
	|--------------------------------------------------------------|
	|							QUERY							   |
	|--------------------------------------------------------------|
	*/
	
	static function query($query, $conid = FALSE)
	{
		$con = self::$connection;

		if($conid != FALSE)
		{
			if(isset(self::$connections[$conid]))
			{
				$con = self::$connections[$conid];
			}
		}

		$query = mysql_query($query, $con); 

		if($query == FALSE)
		{
			$error = 'MySQL query #'.self::$querycount.' failed. ';
			
			if(DEBUG == TRUE)
			{
				$error .= 'MySQL reported: ' . mysql_error(); 
			}

			show_error($error);
		}

		else
		{
			self::$querycount++;
			self::$queries[] = $query;
			return $query;
		}
	}
	
	static function select($table, $WHERE = FALSE, $LIMIT = FALSE)
	{
		$query = "SELECT * FROM $table";

		if($WHERE != FALSE)
		{
			$query .= " WHERE $WHERE";
		}

		if($LIMIT != FALSE)
		{
			$query .= " LIMIT $LIMIT";
		}

		return self::query($query);
	}
	
	/*
	|--------------------------------------------------------------|
	|							RESULT							   |
	|--------------------------------------------------------------|
	*/

	static function num_rows($queryid = FALSE)
	{
		$query = self::getid($queryid);
		return mysql_num_rows($query);
	}

	static function fetch_array($queryid = FALSE)
	{
		$query  = self::getid($queryid);
		$result = array();

		while($row = mysql_fetch_array($query, MYSQL_ASSOC))
		{
			foreach($row as $k => $v)
			{
				$row[$k] = stripslashes($v);
			}

			$result[] = $row;
		}
		
		return $result;
	}

	static function fetch_row($queryid = FALSE, $rowid = 0)
	{
		$result = self::fetch_array($queryid);
		
		if(isset($result[$rowid]))
		{
			return $result[$rowid];
		}
		
		return false;
	}
	
	/*
	| -----------------------------------------------------
	| 						GETID
	|------------------------------------------------------
	|
	| Returns a query's result based off of the numerical
	| id assigned by this class. If the input is FALSE,
	| the latest query's result will be returned.
	*/

	static function getid($queryid = FALSE)
	{
		$query = self::$queries[count(self::$queries)-1];
		
		if($queryid != FALSE)
		{
			if(isset(self::$queries[$queryid]))
			{
				$query = self::$queries[$queryid];
			}
		}

		return $query;
	}
}
